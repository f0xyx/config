#!/usr/bin/env python3
"""
Operasi tingkat batch untuk FoxCrypt GUI/CLI.

Modul ini sengaja tidak mengimpor tkinter supaya bisa diuji headless.
Semua operasi destruktif (shred) hanya dijalankan setelah ciphertext
didekripsi ulang dan dibandingkan dengan plaintext.
"""

from __future__ import annotations

import ctypes
import hashlib
import os
import secrets
import shutil
import stat
import sys
import threading
import time
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from foxcrypt import (
    FoxError,
    decrypt_file,
    encrypt_file,
    read_header,
)

APP_ROOT = Path(__file__).resolve().parent

# Jangan pernah mengenkripsi/menghapus kode aplikasi, virtualenv, atau
# instalasi Python yang sedang dipakai. Ini juga melindungi GUI agar
# tidak menghancurkan dirinya sendiri saat mode drive dijalankan.
_protected: list[Path] = [APP_ROOT]
for _candidate in (
    sys.executable,
    sys.prefix,
    sys.base_prefix,
    sys.exec_prefix,
    sys.base_exec_prefix,
):
    try:
        _path = Path(_candidate).resolve()
        _protected.append(_path)
        if _path.is_file():
            _protected.append(_path.parent)
    except (OSError, RuntimeError):
        pass
PROTECTED_ROOTS = tuple(dict.fromkeys(_protected))

TEMP_PREFIX = ".foxcrypt-"
FOX_SUFFIX = ".fox"

DEFAULT_VERIFY_PASSES = 2
DEFAULT_SHRED_PASSES = 1
DEFAULT_WORKERS = 4
MAX_WORKERS = 100
MAX_PENDING_FACTOR = 1  # antrean per worker; 100 worker = maksimal 200 future

SYSTEM_DIR_NAMES = {
    "$recycle.bin",
    "system volume information",
    "$extend",
    "$winreagent",
    "$sysreset",
    "config.msi",
}
SYSTEM_FILE_NAMES = {
    "pagefile.sys",
    "hiberfil.sys",
    "swapfile.sys",
    "dumpstack.log.tmp",
    "bootmgr",
    "bootnxt",
    "bootsect.bak",
    "desktop.ini",
    "thumbs.db",
    ".ds_store",
}

DRIVE_TYPE_NAMES = {
    0: "Unknown",
    1: "No root",
    2: "Removable",
    3: "Fixed",
    4: "Network",
    5: "CD-ROM",
    6: "RAM disk",
}


class OperationError(FoxError):
    """Kesalahan operasi batch yang aman ditampilkan ke pengguna."""


@dataclass(frozen=True)
class DriveInfo:
    root: str
    label: str
    fs: str
    kind: str
    total: int
    free: int
    is_system: bool

    @property
    def letter(self) -> str:
        if len(self.root) >= 2 and self.root[1] == ":":
            return self.root[0].upper()
        return self.root

    def display(self) -> str:
        label = f" [{self.label}]" if self.label else ""
        flags = []
        if self.is_system:
            flags.append("SYSTEM")
        if self.kind:
            flags.append(self.kind)
        suffix = f" ({', '.join(flags)})" if flags else ""
        return f"{self.root.rstrip(os.sep) or self.root}{label}{suffix}"

    @property
    def is_network(self) -> bool:
        return self.kind.casefold() == "network"

    @property
    def is_optical(self) -> bool:
        return self.kind.casefold() == "cd-rom"


@dataclass
class FileOutcome:
    src: str
    dst: str | None
    ok: bool
    message: str
    size: int = 0
    verify_passes: int = 0
    shredded: bool = False
    skipped: bool = False
    canceled: bool = False


@dataclass
class BatchResult:
    operation: str
    root: str
    mode: str = ""
    outcomes: list[FileOutcome] = field(default_factory=list)
    scan_errors: list[str] = field(default_factory=list)
    audit_errors: list[str] = field(default_factory=list)
    audit_error_count: int = 0
    canceled: bool = False
    started: float = 0.0
    finished: float = 0.0

    @property
    def total(self) -> int:
        return len(self.outcomes)

    @property
    def succeeded(self) -> int:
        return sum(1 for item in self.outcomes if item.ok)

    @property
    def failed(self) -> int:
        return sum(1 for item in self.outcomes if not item.ok)

    @property
    def skipped(self) -> int:
        return sum(1 for item in self.outcomes if item.skipped)

    @property
    def shredded(self) -> int:
        return sum(1 for item in self.outcomes if item.shredded)

    @property
    def elapsed(self) -> float:
        if not self.started:
            return 0.0
        end = self.finished or time.monotonic()
        return max(0.0, end - self.started)

    @property
    def success(self) -> bool:
        return (
            not self.canceled
            and not self.scan_errors
            and not self.audit_errors
            and self.audit_error_count == 0
            and self.failed == 0
        )

    def add_audit_problem(self, message: str) -> None:
        self.audit_error_count += 1
        if len(self.audit_errors) < 20:
            self.audit_errors.append(message)


# ---------------------------------------------------------------------------
# Drive / path helpers
# ---------------------------------------------------------------------------


def _norm(path: str | os.PathLike[str]) -> str:
    # realpath() juga me-resolve symlink/junction agar path yang tampak
    # aman tidak bisa menunjuk ke folder aplikasi/Python.
    absolute = os.path.abspath(os.fspath(path))
    try:
        return os.path.normcase(os.path.realpath(absolute))
    except (OSError, RuntimeError):
        return os.path.normcase(absolute)


def is_within(child: str | os.PathLike[str], parent: str | os.PathLike[str]) -> bool:
    """True jika child ada di dalam parent (case-insensitive di Windows)."""
    try:
        return os.path.commonpath([_norm(child), _norm(parent)]) == _norm(parent)
    except (ValueError, OSError, RuntimeError):
        return False


def _system_drive_letter() -> str:
    return os.environ.get("SystemDrive", "C:")[:1].upper()


def _looks_like_system_volume(root: Path) -> bool:
    markers = (
        Path("Windows") / "System32",
        Path("Recovery") / "WindowsRE",
        Path("WindowsRE"),
        Path("EFI") / "Microsoft",
        Path("System") / "Library" / "CoreServices",
        Path("com.apple.recovery.boot"),
    )
    for marker in markers:
        try:
            if (root / marker).is_dir():
                return True
        except OSError:
            continue
    return False


def _is_windows_system_root(root: Path) -> bool:
    if os.name != "nt":
        return str(root) == os.sep or _looks_like_system_volume(root)
    try:
        drive = str(root)[:1].upper()
    except Exception:
        return False
    if drive == _system_drive_letter():
        return True
    return _looks_like_system_volume(root)


def is_drive_root(path: str | os.PathLike[str]) -> bool:
    text = os.path.abspath(os.fspath(path))
    if os.name == "nt":
        drive, tail = os.path.splitdrive(text)
        return bool(drive) and tail in ("\\", "/", "")
    if os.path.dirname(text) == text:
        return True
    try:
        return any(
            _norm(text) == _norm(info.root) for info in list_drives()
        )
    except Exception:
        return False


def drive_root(path: str | os.PathLike[str]) -> Path:
    text = os.path.abspath(os.fspath(path))
    if os.name == "nt":
        drive, _ = os.path.splitdrive(text)
        return Path(drive + os.sep)
    candidate = Path(text)
    if is_drive_root(candidate) and candidate != Path(os.path.abspath(os.sep)):
        return candidate
    return Path(os.path.abspath(os.sep))


def _windows_drives() -> list[DriveInfo]:
    kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
    kernel32.GetLogicalDrives.restype = ctypes.c_uint32
    kernel32.GetDriveTypeW.argtypes = [ctypes.c_wchar_p]
    kernel32.GetDriveTypeW.restype = ctypes.c_uint
    kernel32.GetVolumeInformationW.argtypes = [
        ctypes.c_wchar_p,
        ctypes.c_wchar_p,
        ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint32),
        ctypes.POINTER(ctypes.c_uint32),
        ctypes.POINTER(ctypes.c_uint32),
        ctypes.c_wchar_p,
        ctypes.c_uint32,
    ]
    kernel32.GetVolumeInformationW.restype = ctypes.c_int

    bitmask = kernel32.GetLogicalDrives()
    drives: list[DriveInfo] = []

    for index in range(26):
        if not (bitmask & (1 << index)):
            continue
        letter = chr(ord("A") + index)
        root = f"{letter}:\\"
        try:
            drive_type = int(kernel32.GetDriveTypeW(ctypes.c_wchar_p(root)))
        except Exception:
            drive_type = 3

        label = ""
        fs = ""
        # Jangan query volume/usage untuk network/CD-ROM: bisa menggantung
        # lama di Windows jika share/media tidak tersedia.
        if drive_type not in (4, 5):
            try:
                label_buf = ctypes.create_unicode_buffer(261)
                fs_buf = ctypes.create_unicode_buffer(261)
                kernel32.GetVolumeInformationW(
                    ctypes.c_wchar_p(root),
                    label_buf,
                    len(label_buf),
                    None,
                    None,
                    None,
                    fs_buf,
                    len(fs_buf),
                )
                label = label_buf.value
                fs = fs_buf.value
            except Exception:
                pass

            total = free = 0
            try:
                usage = shutil.disk_usage(root)
                total, free = usage.total, usage.free
            except OSError:
                pass
        else:
            total = free = 0

        # Drive yang berisi Windows juga dianggap sistem, walaupun
        # SystemDrive bukan drive tersebut (mis. instalasi kedua).
        system = letter.upper() == _system_drive_letter()
        if not system and drive_type not in (4, 5):
            system = _looks_like_system_volume(Path(root))

        drives.append(
            DriveInfo(
                root=root,
                label=label,
                fs=fs,
                kind=DRIVE_TYPE_NAMES.get(drive_type, f"Type {drive_type}"),
                total=total,
                free=free,
                is_system=system,
            )
        )

    return sorted(drives, key=lambda item: item.root)


def _posix_drives() -> list[DriveInfo]:
    candidates: list[Path] = [Path("/")]
    volumes = Path("/Volumes")
    if volumes.is_dir():
        try:
            candidates.extend(
                child for child in sorted(volumes.iterdir()) if child.is_dir()
            )
        except OSError:
            pass

    for base in (Path("/media"), Path("/mnt"), Path("/run/media")):
        if not base.is_dir():
            continue
        try:
            for child in sorted(base.iterdir()):
                if child.is_dir():
                    candidates.append(child)
        except OSError:
            pass

    seen: set[str] = set()
    result: list[DriveInfo] = []
    try:
        root_device = os.stat(os.path.abspath(os.sep)).st_dev
    except OSError:
        root_device = None

    for root in candidates:
        key = str(root)
        if key in seen:
            continue
        seen.add(key)
        try:
            usage = shutil.disk_usage(root)
            total, free = usage.total, usage.free
            device = os.stat(root).st_dev
        except OSError:
            continue

        # Jangan pernah menawarkan volume sistem macOS/Linux sebagai
        # "seluruh drive". Selain root "/", volume Data macOS biasanya
        # berbagi device yang sama dengan "/".
        system = root == Path("/")
        if root_device is not None and device == root_device:
            system = True
        if _looks_like_system_volume(root):
            system = True
        if root.name.casefold() in ("recovery", "macintosh hd"):
            system = True

        result.append(
            DriveInfo(
                root=str(root),
                label=root.name or "/",
                fs="",
                kind="System" if system else "Mounted",
                total=total,
                free=free,
                is_system=system,
            )
        )
    return result


def list_drives() -> list[DriveInfo]:
    """Daftar drive/mount yang bisa dipilih GUI."""
    if os.name == "nt":
        return _windows_drives()
    return _posix_drives()


def format_bytes(value: int) -> str:
    size = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB", "PiB"):
        if size < 1024 or unit == "PiB":
            if unit == "B":
                return f"{int(size)} {unit}"
            return f"{size:.2f} {unit}"
        size /= 1024
    return f"{value} B"


# ---------------------------------------------------------------------------
# Scanning
# ---------------------------------------------------------------------------


def _is_link_like(path: Path) -> bool:
    try:
        st = os.lstat(path)
    except OSError:
        return True
    if stat.S_ISLNK(st.st_mode):
        return True
    try:
        if hasattr(os.path, "isjunction") and os.path.isjunction(path):
            return True
    except OSError:
        return True
    attrs = getattr(st, "st_file_attributes", 0)
    if attrs & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0):
        return True
    return False


def _is_system_attr(path: Path) -> bool:
    try:
        st = os.lstat(path)
    except OSError:
        return True
    attrs = getattr(st, "st_file_attributes", 0)
    return bool(attrs & getattr(stat, "FILE_ATTRIBUTE_SYSTEM", 0))


def _is_protected(path: Path) -> bool:
    return any(is_within(path, root) for root in PROTECTED_ROOTS)


def _should_skip_dir(path: Path) -> bool:
    name = path.name.casefold()
    if name in SYSTEM_DIR_NAMES:
        return True
    if _is_link_like(path):
        return True
    if _is_protected(path):
        return True
    if _is_system_attr(path):
        return True
    return False


def _matches_operation(path: Path, operation: str) -> bool:
    suffix = path.name.casefold().endswith(FOX_SUFFIX)
    return (not suffix) if operation == "encrypt" else suffix


def _should_skip_file(path: Path, operation: str) -> tuple[bool, str]:
    name = path.name.casefold()
    if name in SYSTEM_FILE_NAMES:
        return True, "file sistem/metadata"
    if name.startswith(TEMP_PREFIX):
        return True, "file sementara FoxCrypt"

    try:
        st = os.lstat(path)
    except OSError:
        return True, "tidak bisa membaca metadata"

    if stat.S_ISLNK(st.st_mode):
        return True, "symlink/reparse point"
    try:
        if hasattr(os.path, "isjunction") and os.path.isjunction(path):
            return True, "symlink/reparse point"
    except OSError:
        return True, "tidak bisa membaca metadata"

    attrs = getattr(st, "st_file_attributes", 0)
    if attrs & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0):
        return True, "symlink/reparse point"
    if attrs & getattr(stat, "FILE_ATTRIBUTE_SYSTEM", 0):
        return True, "file bersistem"
    if not stat.S_ISREG(st.st_mode):
        return True, "bukan file biasa"
    if not _matches_operation(path, operation):
        if operation == "encrypt":
            return True, "sudah berekstensi .fox"
        return True, "bukan file .fox"
    return False, ""


def collect_files(
    root: Path,
    *,
    operation: str,
    should_cancel: Callable[[], bool] | None = None,
) -> tuple[list[Path], list[str], bool]:
    """Kumpulkan file yang akan diproses.

    operation = "encrypt" -> semua file non-.fox
    operation = "decrypt" -> semua file .fox
    """
    root = Path(root)
    errors: list[str] = []
    files: list[Path] = []

    if not root.exists():
        raise OperationError(f"Path tidak ditemukan: {root}")
    if _is_link_like(root):
        raise OperationError(
            "Target berupa symlink/reparse point; pilih path aslinya."
        )
    if operation == "encrypt" and _is_protected(root):
        raise OperationError(
            "Folder aplikasi FoxCrypt/Python (dan isinya) tidak boleh "
            "menjadi target enkripsi."
        )

    if root.is_file():
        skip, reason = _should_skip_file(root, operation)
        if skip:
            return [], [f"{root}: dilewati ({reason})"], False
        return [root], [], False
    if not root.is_dir():
        raise OperationError(f"Bukan file/folder: {root}")

    def onerror(exc: OSError) -> None:
        errors.append(f"{getattr(exc, 'filename', root)}: {exc}")

    canceled = False
    for dirpath, dirnames, filenames in os.walk(
        root, topdown=True, onerror=onerror, followlinks=False
    ):
        if should_cancel is not None and should_cancel():
            canceled = True
            break

        current = Path(dirpath)
        dirnames[:] = [
            name
            for name in dirnames
            if not _should_skip_dir(current / name)
        ]
        dirnames.sort(key=str.casefold)

        for name in sorted(filenames, key=str.casefold):
            path = current / name
            skip, reason = _should_skip_file(path, operation)
            if skip:
                # Hanya kegagalan metadata yang dianggap masalah. File
                # sistem/metadata memang dikecualikan sejak awal.
                if reason == "tidak bisa membaca metadata":
                    errors.append(f"{path}: {reason}")
                continue
            files.append(path)

    files.sort(key=lambda item: str(item).casefold())
    return files, errors, canceled


# ---------------------------------------------------------------------------
# Hashing / verified encryption
# ---------------------------------------------------------------------------


def sha256_file(
    path: Path,
    *,
    should_cancel: Callable[[], bool] | None = None,
) -> tuple[bytes, int]:
    digest = hashlib.sha256()
    size = 0
    with Path(path).open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            if should_cancel is not None and should_cancel():
                raise OperationError("Dibatalkan saat menghitung hash.")
            digest.update(block)
            size += len(block)
    return digest.digest(), size


def _safe_unlink(path: Path) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass


def _fsync_dir(path: Path) -> None:
    if os.name == "nt":
        return
    try:
        fd = os.open(path, os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def _verification_temp(fox_path: Path) -> Path:
    for _ in range(10):
        candidate = fox_path.with_name(
            f"{TEMP_PREFIX}verify-{secrets.token_hex(8)}.tmp"
        )
        if not candidate.exists():
            return candidate
    raise OperationError("Tidak bisa membuat nama file verifikasi sementara.")


def verify_ciphertext(
    fox_path: Path,
    *,
    password: str,
    keyfile_digest: bytes | None,
    expected_digest: bytes,
    expected_size: int,
    passes: int,
    should_cancel: Callable[[], bool] | None = None,
) -> None:
    """Dekripsi ulang .fox beberapa kali dan bandingkan SHA-256."""
    if passes < 1:
        raise OperationError("Jumlah pass verifikasi minimal 1.")

    _, header = read_header(fox_path)
    if header.plaintext_size != expected_size:
        raise OperationError(
            "Ukuran plaintext di header .fox tidak cocok dengan file asli."
        )

    for pass_no in range(1, passes + 1):
        if should_cancel is not None and should_cancel():
            raise OperationError("Dibatalkan saat verifikasi.")
        temp = _verification_temp(fox_path)
        try:
            size = decrypt_file(
                fox_path,
                temp,
                password,
                keyfile_digest=keyfile_digest,
                force=False,
            )
            digest, actual_size = sha256_file(temp)
            if size != expected_size or actual_size != expected_size:
                raise OperationError(
                    f"Verifikasi pass {pass_no} gagal: ukuran tidak cocok."
                )
            if not secrets.compare_digest(digest, expected_digest):
                raise OperationError(
                    f"Verifikasi pass {pass_no} gagal: SHA-256 tidak cocok."
                )
        finally:
            _safe_unlink(temp)


def shred_file(
    path: Path,
    *,
    passes: int = DEFAULT_SHRED_PASSES,
    progress: Callable[[int, int], None] | None = None,
    should_cancel: Callable[[], bool] | None = None,
) -> None:
    """Best-effort overwrite + truncate + rename + delete.

    Ini BUKAN jaminan pemulihan mustahil. SSD/NVMe, copy-on-write,
    journal, snapshot, dan free-space remnants dapat menyimpan salinan.
    """
    path = Path(path)
    if passes < 1:
        raise OperationError("Jumlah pass shred minimal 1.")
    if should_cancel is not None and should_cancel():
        raise OperationError("Dibatalkan sebelum shred.")
    if _is_link_like(path):
        raise OperationError("Menolak shred symlink/reparse point.")
    try:
        st = os.stat(path, follow_symlinks=False)
    except OSError as exc:
        raise OperationError(f"Tidak bisa membaca file untuk shred: {exc}")
    if not stat.S_ISREG(st.st_mode):
        raise OperationError("Target shred bukan file biasa.")
    if getattr(st, "st_nlink", 1) > 1:
        raise OperationError(
            "File memiliki hardlink; shred dibatalkan agar hardlink lain "
            "tidak ikut rusak. File asli dipertahankan."
        )
    size = st.st_size

    try:
        os.chmod(path, stat.S_IREAD | stat.S_IWRITE)
    except OSError:
        pass

    if _is_link_like(path):
        raise OperationError("File berubah menjadi symlink sebelum shred.")

    flags = os.O_WRONLY | getattr(os, "O_BINARY", 0)
    flags |= getattr(os, "O_NOFOLLOW", 0)
    try:
        fd = os.open(path, flags)
    except OSError as exc:
        raise OperationError(f"Tidak bisa membuka file untuk shred: {exc}")

    try:
        opened = os.fstat(fd)
        if opened.st_size != size:
            raise OperationError("Ukuran file berubah sebelum shred.")
        block_size = 1024 * 1024
        for pass_no in range(1, passes + 1):
            os.lseek(fd, 0, os.SEEK_SET)
            random_block = secrets.token_bytes(block_size)
            remaining = size
            while remaining:
                chunk = random_block[: min(block_size, remaining)]
                view = memoryview(chunk)
                while view:
                    written = os.write(fd, view)
                    if written <= 0:
                        raise OperationError("Gagal menulis data shred.")
                    view = view[written:]
                remaining -= len(chunk)
            os.ftruncate(fd, size)
            os.fsync(fd)
            if progress is not None:
                progress(pass_no, passes)
        os.ftruncate(fd, 0)
        os.fsync(fd)
    except Exception:
        # File mungkin sudah sebagian ditimpa. Ciphertext .fox tetap ada,
        # jadi data masih bisa dipulihkan lewat foxcrypt decrypt.
        raise
    finally:
        os.close(fd)

    # Pastikan path tidak diganti symlink/reparse point saat kita menutup
    # file. File yang sudah ditimpa harus tetap file yang sama.
    if not os.path.lexists(path):
        return
    if _is_link_like(path):
        raise OperationError("File berubah menjadi symlink setelah shred.")
    try:
        now = os.stat(path, follow_symlinks=False)
        if now.st_size != 0:
            raise OperationError(
                "File berubah setelah shred; penghapusan dibatalkan."
            )
    except FileNotFoundError:
        return
    except OSError as exc:
        raise OperationError(f"Tidak bisa memeriksa file setelah shred: {exc}")

    temp = path.with_name(f"{TEMP_PREFIX}shred-{secrets.token_hex(8)}.tmp")
    renamed = False
    try:
        os.replace(path, temp)
        renamed = True
    except OSError:
        pass

    target = temp if renamed else path
    try:
        os.remove(target)
    except OSError as exc:
        raise OperationError(f"File sudah ditimpa tetapi gagal dihapus: {exc}")
    _fsync_dir(path.parent)

    if path.exists() or path.is_symlink():
        raise OperationError("File asli masih ada setelah proses shred.")


# ---------------------------------------------------------------------------
# Per-file operations
# ---------------------------------------------------------------------------


def encrypt_one(
    src: Path,
    *,
    password: str,
    keyfile_digest: bytes | None,
    shred_original: bool,
    shred_passes: int = DEFAULT_SHRED_PASSES,
    verify_passes: int = DEFAULT_VERIFY_PASSES,
    should_cancel: Callable[[], bool] | None = None,
    log: Callable[[str], None] | None = None,
) -> FileOutcome:
    src = Path(src)
    dst = Path(str(src) + FOX_SUFFIX)

    def emit(message: str) -> None:
        if log is not None:
            log(message)

    if _is_protected(src):
        return FileOutcome(
            str(src),
            None,
            False,
            "Dilewati: file aplikasi FoxCrypt/Python tidak boleh dienkripsi.",
            skipped=True,
        )
    if _is_link_like(src):
        return FileOutcome(
            str(src), None, False, "Dilewati: symlink/reparse point", skipped=True
        )
    try:
        initial_stat = os.stat(src, follow_symlinks=False)
    except OSError as exc:
        return FileOutcome(str(src), None, False, f"Gagal stat: {exc}")
    if not stat.S_ISREG(initial_stat.st_mode):
        return FileOutcome(str(src), None, False, "Bukan file biasa", skipped=True)
    if getattr(initial_stat, "st_nlink", 1) > 1:
        return FileOutcome(
            str(src),
            None,
            False,
            "Dilewati: file memiliki hardlink; shred dapat merusak path lain.",
            skipped=True,
        )
    if src.name.casefold().endswith(FOX_SUFFIX):
        return FileOutcome(
            str(src), None, False, "Dilewati: sudah .fox", skipped=True
        )
    if dst.exists():
        return FileOutcome(
            str(src),
            str(dst),
            False,
            f"File .fox sudah ada; file asli dipertahankan: {dst}",
            skipped=True,
        )

    try:
        before = os.stat(src, follow_symlinks=False)
    except OSError as exc:
        return FileOutcome(str(src), None, False, f"Gagal stat: {exc}")

    try:
        size, _frames, digest = encrypt_file(
            src,
            dst,
            password,
            keyfile_digest=keyfile_digest,
            chunk_size=1024 * 1024,
            force=False,
        )
    except Exception as exc:
        # Jangan unlink dst di sini: secara teori proses lain bisa saja
        # membuat file dengan nama itu. Core sudah membersihkan temp-nya.
        return FileOutcome(str(src), str(dst), False, f"Enkripsi gagal: {exc}")

    try:
        _, header = read_header(dst)
        if header.plaintext_size != size or size != before.st_size:
            raise OperationError("Ukuran .fox tidak cocok dengan file asli.")
    except Exception as exc:
        return FileOutcome(
            str(src),
            str(dst),
            False,
            f"Header .fox tidak valid: {exc}",
        )

    # Pastikan isi file sumber tidak berubah selama enkripsi. Ini penting
    # sebelum file asli diizinkan untuk di-shred.
    try:
        after_digest, after_size = sha256_file(src)
        if after_size != before.st_size or not secrets.compare_digest(
            after_digest, digest
        ):
            return FileOutcome(
                str(src),
                str(dst),
                False,
                "File asli berubah selama enkripsi; file asli TIDAK dihapus.",
            )
    except Exception as exc:
        return FileOutcome(
            str(src),
            str(dst),
            False,
            f"Gagal memeriksa ulang file asli: {exc}",
        )

    emit(f"Verifikasi {verify_passes}x: {src.name}")
    try:
        verify_ciphertext(
            dst,
            password=password,
            keyfile_digest=keyfile_digest,
            expected_digest=digest,
            expected_size=size,
            passes=verify_passes,
            should_cancel=should_cancel,
        )
    except Exception as exc:
        return FileOutcome(
            str(src),
            str(dst),
            False,
            f"Verifikasi gagal; file asli dipertahankan. {exc}",
            size=size,
        )

    if should_cancel is not None and should_cancel():
        return FileOutcome(
            str(src),
            str(dst),
            False,
            "Dibatalkan setelah verifikasi; file asli dipertahankan.",
            size=size,
            verify_passes=verify_passes,
            canceled=True,
        )

    if not shred_original:
        return FileOutcome(
            str(src),
            str(dst),
            True,
            "Terenkripsi & terverifikasi; file asli dipertahankan.",
            size=size,
            verify_passes=verify_passes,
        )

    # Cek terakhir sebelum data asli disentuh.
    try:
        current = os.stat(src, follow_symlinks=False)
    except OSError as exc:
        return FileOutcome(
            str(src),
            str(dst),
            False,
            f"File asli hilang/berubah sebelum shred: {exc}",
            size=size,
            verify_passes=verify_passes,
        )
    if (
        current.st_size != before.st_size
        or current.st_mtime_ns != before.st_mtime_ns
    ):
        return FileOutcome(
            str(src),
            str(dst),
            False,
            "File asli berubah sebelum shred; file asli TIDAK dihapus.",
            size=size,
            verify_passes=verify_passes,
        )

    try:
        emit(f"Shred {shred_passes}x: {src.name}")
        shred_file(
            src,
            passes=shred_passes,
            should_cancel=should_cancel,
        )
    except Exception as exc:
        return FileOutcome(
            str(src),
            str(dst),
            False,
            f"Enkripsi terverifikasi, tetapi shred gagal/partial: {exc}",
            size=size,
            verify_passes=verify_passes,
        )

    if src.exists() or src.is_symlink():
        return FileOutcome(
            str(src),
            str(dst),
            False,
            "File asli masih ada setelah shred.",
            size=size,
            verify_passes=verify_passes,
        )

    return FileOutcome(
        str(src),
        str(dst),
        True,
        f"Terenkripsi, {verify_passes}x verifikasi, shredded best-effort.",
        size=size,
        verify_passes=verify_passes,
        shredded=True,
    )


def decrypt_one(
    src: Path,
    *,
    password: str,
    keyfile_digest: bytes | None,
    log: Callable[[str], None] | None = None,
) -> FileOutcome:
    src = Path(src)
    name = src.name
    if name.casefold().endswith(FOX_SUFFIX) and len(name) > len(FOX_SUFFIX):
        dst = src.with_name(name[: -len(FOX_SUFFIX)])
    else:
        dst = Path(str(src) + ".dec")

    if dst.exists():
        return FileOutcome(
            str(src),
            str(dst),
            False,
            f"Output sudah ada; tidak ditimpa: {dst}",
            skipped=True,
        )
    try:
        size = decrypt_file(
            src,
            dst,
            password,
            keyfile_digest=keyfile_digest,
            force=False,
        )
    except Exception as exc:
        return FileOutcome(str(src), str(dst), False, f"Dekripsi gagal: {exc}")

    try:
        _, header = read_header(src)
        if header.plaintext_size != size or dst.stat().st_size != size:
            raise OperationError("Ukuran hasil dekripsi tidak cocok.")
    except Exception as exc:
        _safe_unlink(dst)
        return FileOutcome(
            str(src), str(dst), False, f"Verifikasi hasil gagal: {exc}"
        )

    if log is not None:
        log(f"Hasil terverifikasi: {dst.name}")
    return FileOutcome(
        str(src),
        str(dst),
        True,
        "Dekripsi & verifikasi ukuran berhasil.",
        size=size,
    )


# ---------------------------------------------------------------------------
# Batch
# ---------------------------------------------------------------------------


@dataclass
class BatchConfig:
    operation: str
    target: Path
    password: str
    mode: str = "folder"  # drive | folder | file
    files: list[Path] = field(default_factory=list)
    keyfile_digest: bytes | None = None
    shred_originals: bool = False
    shred_passes: int = DEFAULT_SHRED_PASSES
    verify_passes: int = DEFAULT_VERIFY_PASSES
    workers: int = DEFAULT_WORKERS


ProgressCallback = Callable[[str, dict], None]


def _emit(on_event: ProgressCallback | None, kind: str, **data) -> None:
    if on_event is not None:
        on_event(kind, data)


def validate_batch_target(config: BatchConfig) -> None:
    target = Path(config.target)
    if config.operation not in ("encrypt", "decrypt"):
        raise OperationError("Operasi harus encrypt/decrypt.")
    if config.mode not in ("drive", "folder", "file"):
        raise OperationError("Mode harus drive/folder/file.")
    if not target.exists():
        raise OperationError(f"Target tidak ditemukan: {target}")
    if _is_link_like(target):
        raise OperationError(
            "Target berupa symlink/reparse point; pilih path aslinya."
        )
    if config.operation == "encrypt" and _is_protected(target):
        raise OperationError(
            "Target berada di folder aplikasi FoxCrypt; enkripsi ditolak."
        )

    if config.mode == "drive":
        if not target.is_dir() or not is_drive_root(target):
            raise OperationError("Mode drive membutuhkan root drive, mis. D:\\.")
        if _is_windows_system_root(target):
            raise OperationError("Drive sistem tidak boleh dienkripsi.")
        root = drive_root(target)
        if os.name == "nt":
            drive = str(root)[:1].upper()
            # Cegah drive yang sama dengan lokasi aplikasi.
            if str(APP_ROOT)[:1].upper() == drive:
                # Aplikasi akan dikecualikan dari scan; tetap boleh, tapi
                # beri peringatan di GUI/log.
                pass
        if config.operation == "encrypt" and not config.shred_originals:
            raise OperationError(
                "Mode drive mewajibkan shred file asli setelah verifikasi."
            )

    if config.mode == "folder" and target.is_dir() and is_drive_root(target):
        raise OperationError(
            "Target adalah root drive; gunakan mode drive dengan konfirmasi."
        )
    if config.mode == "file" and not config.files:
        raise OperationError("Tidak ada file yang dipilih.")
    if not (1 <= config.workers <= MAX_WORKERS):
        raise OperationError(
            f"Worker paralel harus 1..{MAX_WORKERS}; didapat {config.workers}."
        )
    if config.operation == "encrypt" and len(config.password) < 12:
        raise OperationError("Password minimal 12 karakter.")


def _drive_info_for_root(root: Path) -> DriveInfo | None:
    target = _norm(root)
    for info in list_drives():
        try:
            candidate = _norm(info.root)
        except Exception:
            continue
        if candidate == target:
            return info
    return None


def _dedupe_paths(paths: list[Path]) -> list[Path]:
    """Buang path duplikat agar dua worker tidak memproses file yang sama."""
    seen: set[str] = set()
    unique: list[Path] = []
    for path in paths:
        key = os.path.normcase(os.path.abspath(os.fspath(path)))
        if key in seen:
            continue
        seen.add(key)
        unique.append(path)
    return unique


def run_batch(
    config: BatchConfig,
    *,
    on_event: ProgressCallback | None = None,
    should_cancel: Callable[[], bool] | None = None,
) -> BatchResult:
    """Jalankan enkripsi/dekripsi batch dengan audit akhir."""
    result = BatchResult(
        operation=config.operation,
        root=str(config.target),
        mode=config.mode,
        started=time.monotonic(),
    )
    cancel = should_cancel or (lambda: False)
    target = Path(config.target)

    try:
        validate_batch_target(config)
    except Exception as exc:
        result.scan_errors.append(str(exc))
        result.finished = time.monotonic()
        return result

    if config.mode in ("drive", "folder"):
        for protected in PROTECTED_ROOTS:
            if is_within(protected, target):
                _emit(
                    on_event,
                    "log",
                    message=(
                        f"Dikecualikan dari scan (aplikasi/Python): {protected}"
                    ),
                )

    if config.mode == "drive":
        info = _drive_info_for_root(drive_root(target))
        if info is not None:
            if info.is_network or info.is_optical:
                result.scan_errors.append(
                    f"Drive {info.root} bertipe {info.kind}; mode drive "
                    "hanya untuk disk lokal."
                )
                result.finished = time.monotonic()
                return result
            if info.is_system:
                result.scan_errors.append("Drive sistem tidak diizinkan.")
                result.finished = time.monotonic()
                return result
            _emit(
                on_event,
                "log",
                message=(
                    f"Drive {info.root} [{info.label or info.kind}] "
                    f"free {format_bytes(info.free)} / {format_bytes(info.total)}"
                ),
            )

    if config.mode == "file":
        files = [Path(item) for item in config.files]
        scan_errors: list[str] = []
        canceled = False
        if config.operation == "decrypt":
            files = [
                item
                for item in files
                if item.name.casefold().endswith(FOX_SUFFIX)
            ]
    else:
        try:
            files, scan_errors, canceled = collect_files(
                target,
                operation=config.operation,
                should_cancel=cancel,
            )
        except Exception as exc:
            result.scan_errors.append(str(exc))
            result.finished = time.monotonic()
            return result

    files = _dedupe_paths(files)
    result.scan_errors.extend(scan_errors)
    _emit(
        on_event,
        "scan",
        total=len(files),
        errors=len(scan_errors),
        canceled=canceled,
    )
    for error in scan_errors[:20]:
        _emit(on_event, "log", message=f"Scan: {error}")

    if canceled:
        result.canceled = True
        result.finished = time.monotonic()
        return result

    total_files = len(files)
    workers = max(1, min(config.workers, total_files))
    # ThreadPoolExecutor membuat thread sesuai jumlah pekerjaan. Dengan
    # 100 file dan 100 worker, masing-masing worker punya scrypt sendiri
    # (~160 MiB RAM); ini fitur, bukan bug, tetapi GUI memberi peringatan.
    event_lock = threading.Lock()

    def emit(kind: str, **data: object) -> None:
        with event_lock:
            _emit(on_event, kind, **data)

    def process(path: Path, index: int) -> tuple[int, FileOutcome]:
        emit(
            "file_start",
            index=index,
            total=total_files,
            path=str(path),
        )
        try:
            if config.operation == "encrypt":
                outcome = encrypt_one(
                    path,
                    password=config.password,
                    keyfile_digest=config.keyfile_digest,
                    shred_original=config.shred_originals,
                    shred_passes=config.shred_passes,
                    verify_passes=config.verify_passes,
                    should_cancel=cancel,
                    log=lambda message: emit("log", message=message),
                )
            else:
                outcome = decrypt_one(
                    path,
                    password=config.password,
                    keyfile_digest=config.keyfile_digest,
                    log=lambda message: emit("log", message=message),
                )
        except Exception as exc:
            outcome = FileOutcome(
                str(path), None, False, f"Error worker: {exc}"
            )
        return index, outcome

    cancel_logged = False
    submit_window = max(1, workers * MAX_PENDING_FACTOR)
    pending: dict[Future, int] = {}
    next_index = 0

    def fill_pool(pool: ThreadPoolExecutor) -> None:
        nonlocal next_index
        while (
            next_index < total_files
            and len(pending) < submit_window
            and not cancel()
            and not result.canceled
        ):
            path = files[next_index]
            index = next_index + 1
            future = pool.submit(process, path, index)
            pending[future] = index
            next_index += 1

    try:
        with ThreadPoolExecutor(
            max_workers=workers, thread_name_prefix="foxcrypt"
        ) as pool:
            fill_pool(pool)
            if cancel():
                result.canceled = True
                if not cancel_logged:
                    emit("log", message="Dibatalkan oleh pengguna.")
                    cancel_logged = True
            while pending:
                done, _ = wait(set(pending), return_when=FIRST_COMPLETED)
                for future in done:
                    expected_index = pending.pop(future, 0)
                    try:
                        index, outcome = future.result()
                    except Exception as exc:
                        index = expected_index
                        path = (
                            files[index - 1]
                            if 0 < index <= len(files)
                            else Path("?")
                        )
                        outcome = FileOutcome(
                            str(path), None, False, f"Worker error: {exc}"
                        )

                    result.outcomes.append(outcome)
                    emit(
                        "file_done",
                        index=index,
                        completed=len(result.outcomes),
                        total=total_files,
                        outcome=outcome,
                    )
                    if outcome.canceled or cancel():
                        result.canceled = True
                        if not cancel_logged:
                            emit(
                                "log",
                                message="Dibatalkan oleh pengguna.",
                            )
                            cancel_logged = True

                if cancel() or result.canceled:
                    result.canceled = True
                    if not cancel_logged:
                        emit(
                            "log",
                            message="Dibatalkan oleh pengguna.",
                        )
                        cancel_logged = True
                    # Batalkan task yang belum mulai; task yang sedang
                    # berjalan akan selesai dan tidak melakukan shred baru.
                    for future in list(pending):
                        if future.cancel():
                            pending.pop(future, None)
                else:
                    fill_pool(pool)
    except Exception as exc:
        result.scan_errors.append(f"Worker pool gagal: {exc}")

    if cancel() and not result.canceled:
        result.canceled = True
        if not cancel_logged:
            emit("log", message="Dibatalkan oleh pengguna.")
            cancel_logged = True

    # ------------------------------------------------------------------
    # Audit akhir: jangan pernah bilang "done" hanya karena loop selesai.
    # ------------------------------------------------------------------
    if not result.canceled and not result.scan_errors:
        emit("audit_start", message="Audit akhir...")
        _audit_batch(config, result, on_event, cancel)

    result.finished = time.monotonic()
    return result


def _audit_batch(
    config: BatchConfig,
    result: BatchResult,
    on_event: ProgressCallback | None,
    cancel: Callable[[], bool],
) -> None:
    target = Path(config.target)

    # 1. Setiap output yang sukses harus masih ada dan valid.
    for outcome in result.outcomes:
        if not outcome.ok or outcome.dst is None:
            continue
        dst = Path(outcome.dst)
        if not dst.exists() or not dst.is_file():
            result.add_audit_problem(f"Output hilang: {dst}")
            continue
        try:
            if config.operation == "encrypt":
                _, header = read_header(dst)
                if header.plaintext_size != outcome.size:
                    result.add_audit_problem(
                        f"Ukuran header output tidak cocok: {dst}"
                    )
            else:
                if dst.stat().st_size != outcome.size:
                    result.add_audit_problem(
                        f"Ukuran plaintext hasil dekripsi tidak cocok: {dst}"
                    )
                _, header = read_header(Path(outcome.src))
                if header.plaintext_size != outcome.size:
                    result.add_audit_problem(
                        f"Ukuran header sumber tidak cocok: {outcome.src}"
                    )
        except Exception as exc:
            result.add_audit_problem(f"Audit output gagal: {dst}: {exc}")

    # 1b. Kalau shred tidak diminta, file asli harus tetap ada.
    if config.operation == "encrypt" and not config.shred_originals:
        for outcome in result.outcomes:
            if outcome.ok and not Path(outcome.src).exists():
                result.add_audit_problem(
                    f"File asli hilang padahal shred tidak diminta: {outcome.src}"
                )

    # 2. Kalau shred diminta, tidak boleh ada file eligible yang tersisa.
    if config.operation == "encrypt" and config.shred_originals:
        if config.mode == "file":
            remaining = [Path(item) for item in config.files]
            scan_errors: list[str] = []
            canceled = False
        else:
            try:
                remaining, scan_errors, canceled = collect_files(
                    target,
                    operation="encrypt",
                    should_cancel=cancel,
                )
            except Exception as exc:
                result.add_audit_problem(f"Audit scan gagal: {exc}")
                remaining, scan_errors, canceled = [], [], False
        if canceled:
            result.canceled = True
        for error in scan_errors:
            result.add_audit_problem(f"Audit scan: {error}")
        for path in remaining:
            if path.exists():
                result.add_audit_problem(f"File asli masih tersisa: {path}")

    # 3. Cari sisa file sementara FoxCrypt di area target.
    if config.mode == "file":
        dirs = sorted(
            {Path(item).parent for item in config.files},
            key=lambda item: str(item).casefold(),
        )
        try:
            for directory in dirs:
                for child in directory.iterdir():
                    if child.name.casefold().startswith(TEMP_PREFIX):
                        result.add_audit_problem(
                            f"File sementara tertinggal: {child}"
                        )
        except OSError as exc:
            result.add_audit_problem(f"Audit file sementara gagal: {exc}")
    elif target.is_dir():
        try:
            for dirpath, dirnames, filenames in os.walk(
                target, topdown=True, followlinks=False
            ):
                if cancel():
                    result.canceled = True
                    break
                current = Path(dirpath)
                dirnames[:] = [
                    name
                    for name in dirnames
                    if not _should_skip_dir(current / name)
                ]
                for name in filenames:
                    if name.casefold().startswith(TEMP_PREFIX):
                        result.add_audit_problem(
                            f"File sementara tertinggal: {current / name}"
                        )
        except OSError as exc:
            result.add_audit_problem(f"Audit file sementara gagal: {exc}")

    if result.audit_error_count:
        _emit(
            on_event,
            "log",
            message=(
                f"Audit menemukan {result.audit_error_count} masalah. "
                "Status bukan sukses penuh."
            ),
        )
    else:
        _emit(on_event, "log", message="Audit akhir bersih.")
