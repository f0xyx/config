#!/usr/bin/env python3
"""
FoxCrypt v1
===========

Enkripsi file dengan format .fox:
  - AES-256-GCM (default) atau ChaCha20-Poly1305
  - Kunci diturunkan dari password + salt acak memakai scrypt,
    dilanjutkan HKDF-SHA256
  - Keyfile opsional sebagai faktor kedua
  - Setiap chunk diautentikasi; salah password / file diubah / terpotong
    akan ditolak.

SHA-256 BUKAN enkripsi. Di sini SHA-256 dipakai di dalam KDF (scrypt
memakai PBKDF2-HMAC-SHA256, lalu HKDF-SHA256), sedangkan kerahasiaan
datang dari AES-256-GCM / ChaCha20-Poly1305.

Contoh:
  python3 foxcrypt.py encrypt dokumen.pdf
  python3 foxcrypt.py decrypt dokumen.pdf.fox
  python3 foxcrypt.py info dokumen.pdf.fox
"""

from __future__ import annotations

import argparse
import getpass
import hashlib
import hmac
import os
import secrets
import stat
import struct
import sys
import tempfile
import time
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO

try:
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
except ImportError:  # pragma: no cover - pesan yang ramah untuk pengguna
    sys.exit(
        "library 'cryptography' belum terpasang.\n"
        "Jalankan: python3 -m pip install -r requirements.txt"
    )


# ---------------------------------------------------------------------------
# Konstanta format
# ---------------------------------------------------------------------------

TOOL_VERSION = "1.0.0"

MAGIC = b"FOXFILE1"
VERSION = 1

CIPHER_AES_256_GCM = 1
CIPHER_CHACHA20_POLY1305 = 2

KDF_SCRYPT = 1

FLAG_KEYFILE = 0x01
KNOWN_FLAGS = FLAG_KEYFILE

SALT_LEN = 32
NONCE_PREFIX_LEN = 8
TAG_LEN = 16

DEFAULT_CHUNK_SIZE = 1024 * 1024  # 1 MiB
MIN_CHUNK_SIZE = 64 * 1024
MAX_CHUNK_SIZE = 16 * 1024 * 1024

DEFAULT_LOG_N = 17  # scrypt N = 2^17 = 131072 (~128 MiB RAM)
DEFAULT_R = 8
DEFAULT_P = 1
MIN_LOG_N = 14
MAX_LOG_N = 18
MAX_R = 16
MAX_P = 4
MAX_KDF_MEMORY = 512 * 1024 * 1024  # batas anti-DoS, byte

MIN_PASSWORD_LEN = 12

# Header: magic, version, cipher, kdf, log_n, r, p, salt,
#         nonce_prefix, chunk_size, flags, plaintext_size
HEADER = struct.Struct(">8sBBBBII32s8sIIQ")

# Frame: plaintext_len, counter, final
FRAME = struct.Struct(">IIB")

CIPHERS = {
    "aes256gcm": (CIPHER_AES_256_GCM, "AES-256-GCM"),
    "chacha20poly1305": (CIPHER_CHACHA20_POLY1305, "ChaCha20-Poly1305"),
}
CIPHER_NAMES = {cid: label for cid, label in CIPHERS.values()}


class FoxError(Exception):
    """Kesalahan yang aman ditampilkan ke pengguna."""


@dataclass(frozen=True)
class Header:
    cipher_id: int
    log_n: int
    r: int
    p: int
    salt: bytes
    nonce_prefix: bytes
    chunk_size: int
    flags: int
    plaintext_size: int

    @property
    def cipher_name(self) -> str:
        return CIPHER_NAMES[self.cipher_id]

    @property
    def requires_keyfile(self) -> bool:
        return bool(self.flags & FLAG_KEYFILE)

    @property
    def scrypt_n(self) -> int:
        return 1 << self.log_n


# ---------------------------------------------------------------------------
# Header / parameter validation
# ---------------------------------------------------------------------------


def build_header(header: Header) -> bytes:
    return HEADER.pack(
        MAGIC,
        VERSION,
        header.cipher_id,
        KDF_SCRYPT,
        header.log_n,
        header.r,
        header.p,
        header.salt,
        header.nonce_prefix,
        header.chunk_size,
        header.flags,
        header.plaintext_size,
    )


def validate_params(
    *,
    cipher_id: int,
    log_n: int,
    r: int,
    p: int,
    chunk_size: int,
    flags: int,
) -> None:
    if cipher_id not in CIPHER_NAMES:
        raise FoxError("Algoritma enkripsi di header tidak dikenal.")
    if not (MIN_LOG_N <= log_n <= MAX_LOG_N):
        raise FoxError(
            f"Parameter KDF di luar batas aman (log_n={log_n}); "
            f"harus {MIN_LOG_N}..{MAX_LOG_N}."
        )
    if not (1 <= r <= MAX_R) or not (1 <= p <= MAX_P):
        raise FoxError("Parameter scrypt (r/p) di luar batas aman.")
    if not (MIN_CHUNK_SIZE <= chunk_size <= MAX_CHUNK_SIZE):
        raise FoxError(
            f"Ukuran chunk tidak valid ({chunk_size} byte); "
            f"harus {MIN_CHUNK_SIZE}..{MAX_CHUNK_SIZE}."
        )
    if flags & ~KNOWN_FLAGS:
        raise FoxError("Flag format .fox tidak dikenal.")
    memory = 128 * (1 << log_n) * r
    if memory > MAX_KDF_MEMORY:
        raise FoxError(
            "File meminta memori KDF terlalu besar "
            f"({memory // (1024 * 1024)} MiB)."
        )


def parse_header(raw: bytes) -> Header:
    if len(raw) != HEADER.size:
        raise FoxError("Header .fox tidak lengkap.")
    (
        magic,
        version,
        cipher_id,
        kdf_id,
        log_n,
        r,
        p,
        salt,
        nonce_prefix,
        chunk_size,
        flags,
        plaintext_size,
    ) = HEADER.unpack(raw)

    if magic != MAGIC:
        raise FoxError("Bukan file FoxCrypt (.fox) yang valid.")
    if version != VERSION:
        raise FoxError(f"Versi FoxCrypt tidak didukung (versi {version}).")
    if kdf_id != KDF_SCRYPT:
        raise FoxError("Metode KDF di header tidak dikenal.")

    validate_params(
        cipher_id=cipher_id,
        log_n=log_n,
        r=r,
        p=p,
        chunk_size=chunk_size,
        flags=flags,
    )
    return Header(
        cipher_id=cipher_id,
        log_n=log_n,
        r=r,
        p=p,
        salt=salt,
        nonce_prefix=nonce_prefix,
        chunk_size=chunk_size,
        flags=flags,
        plaintext_size=plaintext_size,
    )


def read_header(path: Path) -> tuple[bytes, Header]:
    with path.open("rb") as fh:
        raw = fh.read(HEADER.size)
    if len(raw) != HEADER.size:
        raise FoxError("File terlalu pendek / bukan file .fox yang valid.")
    return raw, parse_header(raw)


# ---------------------------------------------------------------------------
# KDF dan cipher
# ---------------------------------------------------------------------------


def _encode_password(password: str) -> bytes:
    """NFC + UTF-8, dengan error yang ramah untuk karakter tidak valid."""
    try:
        normalized = unicodedata.normalize("NFC", password)
        return normalized.encode("utf-8")
    except (UnicodeEncodeError, ValueError):
        raise FoxError("Password mengandung karakter Unicode yang tidak valid.")


def _password_material(password: str, keyfile_digest: bytes | None) -> bytes:
    """Campur password + keyfile dengan SHA-256 sebelum scrypt.

    Normalisasi NFC mencegah password Unicode yang tampak sama tetapi
    byte-nya berbeda (mis. e + combining acute vs é).
    """
    encoded = _encode_password(password)
    material = hashlib.sha256(b"FOXCRYPT-v1-password\x00" + encoded).digest()
    if keyfile_digest is not None:
        material = hashlib.sha256(
            b"FOXCRYPT-v1-keyfile\x00" + material + keyfile_digest
        ).digest()
    return material


def derive_key(
    password: str,
    keyfile_digest: bytes | None,
    header: Header,
) -> bytes:
    n = header.scrypt_n
    memory = 128 * n * header.r
    maxmem = memory + (128 * header.r * header.p) + (32 * 1024 * 1024)

    try:
        stretched = hashlib.scrypt(
            _password_material(password, keyfile_digest),
            salt=header.salt,
            n=n,
            r=header.r,
            p=header.p,
            dklen=32,
            maxmem=maxmem,
        )
    except (ValueError, MemoryError) as exc:
        raise FoxError(f"Gagal menurunkan kunci (scrypt): {exc}")
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=header.salt,
        info=b"FOXCRYPT-v1-file-encryption-key",
    ).derive(stretched)


def make_aead(cipher_id: int, key: bytes):
    if cipher_id == CIPHER_AES_256_GCM:
        return AESGCM(key)
    if cipher_id == CIPHER_CHACHA20_POLY1305:
        return ChaCha20Poly1305(key)
    raise FoxError("Algoritma enkripsi tidak dikenal.")


def chunk_nonce(nonce_prefix: bytes, counter: int) -> bytes:
    if not 0 <= counter <= 0xFFFFFFFF:
        raise FoxError("Terlalu banyak chunk dalam satu file.")
    return nonce_prefix + counter.to_bytes(4, "big")


def hash_keyfile(path: Path) -> bytes:
    if not path.exists():
        raise FoxError(f"Keyfile tidak ditemukan: {path}")
    if not path.is_file():
        raise FoxError(f"Keyfile bukan file biasa: {path}")
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(block)
    return digest.digest()


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------


def _read_exact(fh: BinaryIO, size: int) -> bytes:
    parts: list[bytes] = []
    remaining = size
    while remaining:
        block = fh.read(remaining)
        if not block:
            raise FoxError("File .fox terpotong atau rusak.")
        parts.append(block)
        remaining -= len(block)
    return b"".join(parts)


def _new_temp(dst: Path) -> tuple[BinaryIO, Path]:
    try:
        fd, name = tempfile.mkstemp(
            prefix=".foxcrypt-",
            suffix=".tmp",
            dir=str(dst.parent),
        )
    except OSError as exc:
        raise FoxError(f"Tidak bisa membuat file sementara di {dst.parent}: {exc}")

    tmp_path = Path(name)
    try:
        if hasattr(os, "fchmod"):
            os.fchmod(fd, 0o600)
        else:  # Windows tidak punya os.fchmod
            os.chmod(tmp_path, 0o600)
        return os.fdopen(fd, "wb"), tmp_path
    except OSError as exc:
        try:
            os.close(fd)
        except OSError:
            pass
        _unlink_quiet(tmp_path)
        raise FoxError(f"Tidak bisa menyiapkan file sementara: {exc}")


def _unlink_quiet(path: Path) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass


def _fsync_dir(path: Path) -> None:
    try:
        fd = os.open(path, os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def _commit_temp(tmp: Path, dst: Path, force: bool) -> None:
    if force:
        try:
            os.replace(tmp, dst)
        except OSError as exc:
            raise FoxError(f"Gagal menulis output: {exc}")
    else:
        try:
            os.link(tmp, dst)  # atomik, gagal jika dst sudah ada
        except FileExistsError:
            raise FoxError(
                f"Output sudah ada: {dst}\nGunakan --force untuk menimpa."
            )
        except OSError:
            # Beberapa filesystem (mis. exFAT/FAT32) atau Windows tanpa
            # privilege hard-link tidak mendukung os.link. Reservasi nama
            # output secara eksklusif, lalu ganti dengan file sementara
            # secara atomik.
            try:
                fd = os.open(dst, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            except FileExistsError:
                raise FoxError(
                    f"Output sudah ada: {dst}\nGunakan --force untuk menimpa."
                )
            except OSError as exc2:
                raise FoxError(f"Gagal menulis output: {exc2}")
            else:
                os.close(fd)
            try:
                os.replace(tmp, dst)
            except OSError as exc3:
                _unlink_quiet(dst)
                raise FoxError(f"Gagal menulis output: {exc3}")
        else:
            _unlink_quiet(tmp)
    _fsync_dir(dst.parent)


def _validate_paths(src: Path, dst: Path, *, force: bool) -> None:
    if not src.exists():
        raise FoxError(f"File input tidak ditemukan: {src}")
    if not src.is_file():
        raise FoxError(f"Input bukan file biasa: {src}")
    if dst.exists() and dst.is_dir():
        raise FoxError(f"Output adalah direktori: {dst}")
    if not dst.parent.exists():
        raise FoxError(f"Direktori output tidak ada: {dst.parent}")
    if not dst.parent.is_dir():
        raise FoxError(f"Path output bukan direktori: {dst.parent}")

    try:
        same = src.resolve() == dst.resolve()
    except OSError:
        same = False
    if not same and dst.exists():
        try:
            same = os.path.samefile(src, dst)
        except OSError:
            pass
    if same:
        raise FoxError("File input dan output tidak boleh sama.")
    if dst.exists() and not force:
        raise FoxError(
            f"Output sudah ada: {dst}\nGunakan --force untuk menimpa."
        )


# ---------------------------------------------------------------------------
# Enkripsi / dekripsi
# ---------------------------------------------------------------------------


def encrypt_file(
    src: Path,
    dst: Path,
    password: str,
    *,
    keyfile_digest: bytes | None = None,
    cipher_name: str = "aes256gcm",
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    log_n: int = DEFAULT_LOG_N,
    r: int = DEFAULT_R,
    p: int = DEFAULT_P,
    force: bool = False,
) -> tuple[int, int, bytes]:
    """Enkripsi src -> dst.

    Mengembalikan (ukuran plaintext, jumlah frame, SHA-256 plaintext).
    Digest dihitung dari byte yang benar-benar dibaca dan dienkripsi.
    """
    if not password:
        raise FoxError("Password tidak boleh kosong.")
    if len(unicodedata.normalize("NFC", password)) < MIN_PASSWORD_LEN:
        raise FoxError(f"Password minimal {MIN_PASSWORD_LEN} karakter.")
    if cipher_name not in CIPHERS:
        raise FoxError(f"Cipher tidak dikenal: {cipher_name}")
    cipher_id, _ = CIPHERS[cipher_name]
    validate_params(
        cipher_id=cipher_id,
        log_n=log_n,
        r=r,
        p=p,
        chunk_size=chunk_size,
        flags=FLAG_KEYFILE if keyfile_digest is not None else 0,
    )

    with src.open("rb") as fin:
        st = os.fstat(fin.fileno())
        if not stat.S_ISREG(st.st_mode):
            raise FoxError("Input bukan file biasa.")
        plaintext_size = st.st_size

        header = Header(
            cipher_id=cipher_id,
            log_n=log_n,
            r=r,
            p=p,
            salt=secrets.token_bytes(SALT_LEN),
            nonce_prefix=secrets.token_bytes(NONCE_PREFIX_LEN),
            chunk_size=chunk_size,
            flags=FLAG_KEYFILE if keyfile_digest is not None else 0,
            plaintext_size=plaintext_size,
        )
        raw_header = build_header(header)

        key = derive_key(password, keyfile_digest, header)
        aead = make_aead(cipher_id, key)

        tmp, tmp_path = _new_temp(dst)
        frames = 0
        total = 0
        plain_hasher = hashlib.sha256()
        try:
            with tmp as fout:
                fout.write(raw_header)

                buf = fin.read(chunk_size)
                counter = 0
                while True:
                    nxt = fin.read(chunk_size)
                    final = len(nxt) == 0
                    frame_header = FRAME.pack(
                        len(buf), counter, 1 if final else 0
                    )
                    aad = raw_header + frame_header
                    ciphertext = aead.encrypt(
                        chunk_nonce(header.nonce_prefix, counter),
                        buf,
                        aad,
                    )
                    fout.write(frame_header)
                    fout.write(ciphertext)
                    plain_hasher.update(buf)

                    frames += 1
                    total += len(buf)
                    counter += 1

                    if final:
                        break
                    buf = nxt

                if total != plaintext_size:
                    raise FoxError(
                        "File sumber berubah ukurannya saat enkripsi. "
                        "Proses dibatalkan."
                    )

                fout.flush()
                os.fsync(fout.fileno())

            _commit_temp(tmp_path, dst, force)
        except BaseException:
            _unlink_quiet(tmp_path)
            raise

    return total, frames, plain_hasher.digest()


def decrypt_file(
    src: Path,
    dst: Path,
    password: str,
    *,
    keyfile_digest: bytes | None = None,
    force: bool = False,
) -> int:
    """Dekripsi src -> dst. Mengembalikan ukuran plaintext."""
    with src.open("rb") as fin:
        raw_header = fin.read(HEADER.size)
        if len(raw_header) != HEADER.size:
            raise FoxError("File terlalu pendek / bukan file .fox yang valid.")
        header = parse_header(raw_header)

        if header.requires_keyfile and keyfile_digest is None:
            raise FoxError("File ini membutuhkan --keyfile untuk didekripsi.")
        if not header.requires_keyfile and keyfile_digest is not None:
            raise FoxError(
                "File ini tidak memakai keyfile; jangan berikan --keyfile."
            )

        key = derive_key(password, keyfile_digest, header)
        aead = make_aead(header.cipher_id, key)

        tmp, tmp_path = _new_temp(dst)
        total = 0
        counter = 0
        try:
            with tmp as fout:
                while True:
                    frame_header = _read_exact(fin, FRAME.size)
                    plain_len, frame_counter, final_flag = FRAME.unpack(
                        frame_header
                    )

                    if frame_counter != counter:
                        raise FoxError("Urutan chunk tidak valid (file rusak).")
                    if final_flag not in (0, 1):
                        raise FoxError("Penanda akhir chunk tidak valid.")
                    if plain_len > header.chunk_size:
                        raise FoxError("Ukuran chunk melebihi batas header.")
                    if not final_flag and plain_len != header.chunk_size:
                        raise FoxError("Chunk non-final tidak berukuran penuh.")
                    if total + plain_len > header.plaintext_size:
                        raise FoxError(
                            "Ukuran plaintext tidak cocok dengan header."
                        )

                    ciphertext = _read_exact(fin, plain_len + TAG_LEN)
                    try:
                        plaintext = aead.decrypt(
                            chunk_nonce(header.nonce_prefix, counter),
                            ciphertext,
                            raw_header + frame_header,
                        )
                    except InvalidTag:
                        raise FoxError(
                            "Password/keyfile salah, atau file .fox "
                            "rusak/diubah. Dekripsi dibatalkan."
                        )

                    fout.write(plaintext)
                    total += plain_len

                    if final_flag:
                        if total != header.plaintext_size:
                            raise FoxError("Ukuran plaintext tidak sesuai header.")
                        if fin.read(1) != b"":
                            raise FoxError(
                                "Ada data tambahan setelah chunk final "
                                "(file rusak/dimanipulasi)."
                            )
                        break

                    if total >= header.plaintext_size:
                        raise FoxError("Chunk final tidak ditemukan.")
                    counter += 1

                fout.flush()
                os.fsync(fout.fileno())

            _commit_temp(tmp_path, dst, force)
        except BaseException:
            _unlink_quiet(tmp_path)
            raise

    return total


# ---------------------------------------------------------------------------
# Password / keyfile CLI
# ---------------------------------------------------------------------------


def _read_secret_file(path: str) -> str:
    try:
        data = Path(path).read_bytes()
    except OSError as exc:
        raise FoxError(f"Tidak bisa membaca file password: {exc}")
    if data.endswith(b"\r\n"):
        data = data[:-2]
    elif data.endswith(b"\n"):
        data = data[:-1]
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        raise FoxError("File password harus berupa teks UTF-8.")


def _get_password(args: argparse.Namespace, *, encrypting: bool) -> str:
    sources = [
        args.password_env is not None,
        args.password_file is not None,
        args.password_stdin,
    ]
    if sum(sources) > 1:
        raise FoxError(
            "Pilih salah satu saja: --password-env, --password-file, "
            "atau --password-stdin."
        )

    if args.password_env is not None:
        value = os.environ.get(args.password_env)
        if value is None:
            raise FoxError(
                f"Environment variable '{args.password_env}' tidak di-set."
            )
        password = value
    elif args.password_file is not None:
        password = _read_secret_file(args.password_file)
    elif args.password_stdin:
        try:
            password = sys.stdin.buffer.read().decode("utf-8")
        except UnicodeDecodeError:
            raise FoxError("Password dari stdin harus berupa teks UTF-8.")
        if password.endswith("\r\n"):
            password = password[:-2]
        elif password.endswith("\n"):
            password = password[:-1]
    else:
        try:
            password = getpass.getpass("Password: ")
            if encrypting:
                again = getpass.getpass("Ulangi password: ")
                if not hmac.compare_digest(
                    _encode_password(password), _encode_password(again)
                ):
                    raise FoxError("Password tidak sama.")
        except EOFError:
            raise FoxError("Tidak bisa membaca password dari terminal.")
        except KeyboardInterrupt:
            raise FoxError("Dibatalkan.")

    if not password:
        raise FoxError("Password tidak boleh kosong.")
    if encrypting and len(password) < MIN_PASSWORD_LEN:
        raise FoxError(
            f"Password minimal {MIN_PASSWORD_LEN} karakter. "
            "Gunakan password manager / passphrase panjang."
        )
    return password


def _default_encrypt_path(src: Path) -> Path:
    return Path(str(src) + ".fox")


def _default_decrypt_path(src: Path) -> Path:
    name = src.name
    if name.lower().endswith(".fox") and len(name) > 4:
        return src.with_name(name[:-4])
    return Path(str(src) + ".dec")


def _fmt_bytes(value: int) -> str:
    size = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if size < 1024 or unit == "TiB":
            if unit == "B":
                return f"{int(size)} {unit}"
            return f"{size:.2f} {unit}"
        size /= 1024
    return f"{value} B"


# ---------------------------------------------------------------------------
# Subcommand implementations
# ---------------------------------------------------------------------------


def cmd_encrypt(args: argparse.Namespace) -> int:
    src = Path(args.input)
    dst = Path(args.output) if args.output else _default_encrypt_path(src)
    _validate_paths(src, dst, force=args.force)

    if not (MIN_CHUNK_SIZE <= args.chunk_size <= MAX_CHUNK_SIZE):
        raise FoxError(
            f"Ukuran chunk harus {MIN_CHUNK_SIZE}..{MAX_CHUNK_SIZE} byte "
            f"(64 KiB..16 MiB); didapat {args.chunk_size} byte."
        )

    kf = hash_keyfile(Path(args.keyfile)) if args.keyfile else None
    password = _get_password(args, encrypting=True)

    started = time.monotonic()
    size, frames, _digest = encrypt_file(
        src,
        dst,
        password,
        keyfile_digest=kf,
        cipher_name=args.cipher,
        chunk_size=args.chunk_size,
        force=args.force,
    )

    elapsed = time.monotonic() - started
    label = CIPHERS[args.cipher][1]
    print(
        f"OK  {src} -> {dst}\n"
        f"    {label}, {_fmt_bytes(size)}, {frames} chunk, "
        f"{elapsed:.2f} detik"
    )
    return 0


def cmd_decrypt(args: argparse.Namespace) -> int:
    src = Path(args.input)
    dst = Path(args.output) if args.output else _default_decrypt_path(src)
    _validate_paths(src, dst, force=args.force)

    # Preflight header supaya kesalahan keyfile/flags ketahuan sebelum
    # pengguna diminta mengetik password.
    _, header = read_header(src)
    if header.requires_keyfile and not args.keyfile:
        raise FoxError("File ini membutuhkan --keyfile.")
    if not header.requires_keyfile and args.keyfile:
        raise FoxError(
            "File ini tidak memakai keyfile; jangan berikan --keyfile."
        )

    kf = hash_keyfile(Path(args.keyfile)) if args.keyfile else None
    password = _get_password(args, encrypting=False)

    started = time.monotonic()
    size = decrypt_file(
        src,
        dst,
        password,
        keyfile_digest=kf,
        force=args.force,
    )
    elapsed = time.monotonic() - started
    print(
        f"OK  {src} -> {dst}\n"
        f"    {_fmt_bytes(size)} plaintext, {elapsed:.2f} detik"
    )
    return 0


def cmd_info(args: argparse.Namespace) -> int:
    src = Path(args.input)
    if not src.is_file():
        raise FoxError(f"File tidak ditemukan: {src}")
    _, h = read_header(src)
    print(f"File          : {src}")
    print("Format        : FoxCrypt v1")
    print(f"Cipher        : {h.cipher_name}")
    print(
        f"KDF           : scrypt N=2^{h.log_n} ({h.scrypt_n}), "
        f"r={h.r}, p={h.p} + HKDF-SHA256"
    )
    print(f"Keyfile       : {'ya' if h.requires_keyfile else 'tidak'}")
    print(f"Chunk size    : {_fmt_bytes(h.chunk_size)}")
    print(f"Plaintext     : {_fmt_bytes(h.plaintext_size)}")
    print(
        "Catatan       : header baru diverifikasi penuh saat decrypt; "
        "info ini belum mengautentikasi isi file."
    )
    return 0


def cmd_sha256(args: argparse.Namespace) -> int:
    path = Path(args.input)
    if not path.is_file():
        raise FoxError(f"File tidak ditemukan: {path}")
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(block)
    print(f"{digest.hexdigest()}  {path}")
    return 0


# ---------------------------------------------------------------------------
# argparse
# ---------------------------------------------------------------------------


def _add_password_args(parser: argparse.ArgumentParser) -> None:
    group = parser.add_argument_group("sumber password")
    group.add_argument(
        "--password-env",
        metavar="VAR",
        help="baca password dari environment variable VAR",
    )
    group.add_argument(
        "--password-file",
        metavar="FILE",
        help="baca password dari file UTF-8 (newline akhir diabaikan)",
    )
    group.add_argument(
        "--password-stdin",
        action="store_true",
        help="baca password dari stdin",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="foxcrypt",
        description=(
            "Enkripsi file ke format .fox dengan AES-256-GCM / "
            "ChaCha20-Poly1305, scrypt + HKDF-SHA256."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "FoxCrypt version " + TOOL_VERSION + "\n\n"
            "Contoh:\n"
            "  %(prog)s encrypt dokumen.pdf\n"
            "  %(prog)s decrypt dokumen.pdf.fox\n"
            "  %(prog)s encrypt rahasia.tar.gz --keyfile ~/.keys/fox.key\n"
            "  %(prog)s info dokumen.pdf.fox\n"
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"FoxCrypt {TOOL_VERSION}",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    enc = sub.add_parser("encrypt", aliases=["e"], help="enkripsi file")
    enc.add_argument("input", help="file yang akan dienkripsi")
    enc.add_argument("-o", "--output", help="path output .fox")
    enc.add_argument(
        "--cipher",
        choices=sorted(CIPHERS),
        default="aes256gcm",
        help="algoritma (default: aes256gcm)",
    )
    enc.add_argument(
        "--keyfile",
        metavar="FILE",
        help="file kunci tambahan (faktor kedua)",
    )
    enc.add_argument(
        "--chunk-size",
        default="1M",
        help="ukuran chunk, mis. 64K/1M/4M (default: 1M)",
    )
    enc.add_argument(
        "--force",
        action="store_true",
        help="timpa output jika sudah ada",
    )
    _add_password_args(enc)
    enc.set_defaults(func=cmd_encrypt)

    dec = sub.add_parser("decrypt", aliases=["d"], help="dekripsi file .fox")
    dec.add_argument("input", help="file .fox yang akan didekripsi")
    dec.add_argument("-o", "--output", help="path output plaintext")
    dec.add_argument(
        "--keyfile",
        metavar="FILE",
        help="file kunci tambahan yang dipakai saat enkripsi",
    )
    dec.add_argument(
        "--force",
        action="store_true",
        help="timpa output jika sudah ada",
    )
    _add_password_args(dec)
    dec.set_defaults(func=cmd_decrypt)

    info = sub.add_parser("info", help="tampilkan header file .fox")
    info.add_argument("input", help="file .fox")
    info.set_defaults(func=cmd_info)

    sha = sub.add_parser(
        "sha256", aliases=["hash"], help="hitung SHA-256 sebuah file"
    )
    sha.add_argument("input", help="file yang dihitung hash-nya")
    sha.set_defaults(func=cmd_sha256)

    return parser


def _parse_chunk_size(value: str) -> int:
    text = value.strip().lower().replace("_", "")
    multipliers = {
        "k": 1024,
        "kb": 1024,
        "kib": 1024,
        "m": 1024 * 1024,
        "mb": 1024 * 1024,
        "mib": 1024 * 1024,
        "g": 1024 * 1024 * 1024,
        "gb": 1024 * 1024 * 1024,
        "gib": 1024 * 1024 * 1024,
    }
    for suffix in sorted(multipliers, key=len, reverse=True):
        if text.endswith(suffix):
            number = text[: -len(suffix)]
            break
    else:
        try:
            return int(text)
        except ValueError:
            raise FoxError(f"Ukuran chunk tidak valid: {value}")
    try:
        result = int(number) * multipliers[suffix]
    except ValueError:
        raise FoxError(f"Ukuran chunk tidak valid: {value}")
    return result


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.func is cmd_encrypt:
        try:
            args.chunk_size = _parse_chunk_size(args.chunk_size)
        except FoxError as exc:
            parser.error(str(exc))

    try:
        return int(args.func(args))
    except FoxError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except OSError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nDibatalkan.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
