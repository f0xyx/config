#!/usr/bin/env python3
"""
Launcher FoxCrypt GUI.

Tugas:
  1. Membuat .venv jika belum ada.
  2. Memasang cryptography otomatis jika belum tersedia.
  3. Memastikan tkinter tersedia.
  4. Menjalankan foxcrypt_gui.py dengan Python dari venv.

Dijalankan oleh FoxCrypt.bat di Windows.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parent
# Pisahkan venv Windows dari venv POSIX agar folder proyek bisa
# disalin/di-zip antara macOS/Linux dan Windows tanpa bentrok.
VENV = PROJECT / (".venv-win" if os.name == "nt" else ".venv")
REQUIREMENTS = PROJECT / "requirements.txt"
GUI = PROJECT / "foxcrypt_gui.py"


def venv_python() -> Path:
    if os.name == "nt":
        return VENV / "Scripts" / "python.exe"
    return VENV / "bin" / "python"


def has_module(python: str, module: str) -> bool:
    try:
        result = subprocess.run(
            [python, "-c", f"import {module}"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except OSError:
        return False
    return result.returncode == 0


def run_checked(command: list[str], *, label: str) -> None:
    print(label)
    try:
        subprocess.check_call(command)
    except OSError as exc:
        raise SystemExit(f"{label} gagal: {exc}")
    except subprocess.CalledProcessError as exc:
        raise SystemExit(
            f"{label} gagal (exit code {exc.returncode}).\n"
            "Periksa koneksi internet dan izin folder aplikasi."
        )


def ensure_venv() -> str:
    python = venv_python()
    if python.is_file():
        return str(python)

    print("Virtualenv belum ada. Membuat .venv ...")
    run_checked(
        [sys.executable, "-m", "venv", str(VENV)],
        label="Membuat virtualenv",
    )
    if not python.is_file():
        raise SystemExit(
            "Gagal membuat .venv. Pastikan Python 3.10+ terpasang dengan "
            "modul venv."
        )
    return str(python)


def ensure_dependencies(python: str) -> None:
    if has_module(python, "cryptography"):
        return

    print("Dependency 'cryptography' belum ada. Memasang otomatis...")
    run_checked(
        [python, "-m", "pip", "install", "--upgrade", "pip"],
        label="Memperbarui pip",
    )
    run_checked(
        [python, "-m", "pip", "install", "-r", str(REQUIREMENTS)],
        label="Memasang cryptography",
    )
    if not has_module(python, "cryptography"):
        raise SystemExit(
            "cryptography masih tidak bisa diimpor setelah instalasi. "
            "Coba jalankan manual:\n"
            f"  {python} -m pip install -r {REQUIREMENTS}"
        )


def ensure_tkinter(python: str) -> None:
    if has_module(python, "tkinter"):
        return
    raise SystemExit(
        "tkinter tidak tersedia di Python ini.\n"
        "Windows: instal Python dari https://www.python.org/downloads/windows/ "
        "(tkinter sudah termasuk) lalu jalankan lagi FoxCrypt.bat.\n"
        "Linux: sudo apt install python3-tk\n"
        "macOS Homebrew: brew install python-tk"
    )


def launch(python: str) -> None:
    if not GUI.is_file():
        raise SystemExit(f"File GUI tidak ditemukan: {GUI}")

    if os.name == "nt":
        # pythonw.exe supaya GUI tidak membuka jendela konsol tambahan.
        pythonw = VENV / "Scripts" / "pythonw.exe"
        executable = str(pythonw) if pythonw.is_file() else python
        subprocess.Popen(
            [executable, str(GUI)],
            cwd=str(PROJECT),
            close_fds=True,
        )
        return

    os.execv(python, [python, str(GUI)])


def main() -> int:
    cli_mode = len(sys.argv) > 1 and sys.argv[1] == "--cli"
    print("FoxCrypt launcher", flush=True)
    print(f"Project: {PROJECT}", flush=True)

    python = ensure_venv()
    ensure_dependencies(python)

    if cli_mode:
        command = [python, str(PROJECT / "foxcrypt.py"), *sys.argv[2:]]
        return subprocess.call(command)

    ensure_tkinter(python)
    launch(python)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
