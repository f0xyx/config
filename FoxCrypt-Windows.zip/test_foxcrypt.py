#!/usr/bin/env python3
"""Tes end-to-end CLI FoxCrypt."""

from __future__ import annotations

import hashlib
import os
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

PROJECT = Path(__file__).resolve().parent
SCRIPT = PROJECT / "foxcrypt.py"
PASSWORD = "correct horse battery staple 2026"
PASSWORD_ENV = "FOXCRYPT_TEST_PASSWORD"


class FoxCryptTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.dir = Path(self.temp.name)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def run_cli(
        self,
        *args: object,
        password: str = PASSWORD,
        stdin: str | None = None,
    ) -> subprocess.CompletedProcess[str]:
        env = os.environ.copy()
        env[PASSWORD_ENV] = password
        cmd = [sys.executable, str(SCRIPT), *(str(a) for a in args)]
        return subprocess.run(
            cmd,
            cwd=PROJECT,
            env=env,
            input=stdin,
            capture_output=True,
            text=True,
            timeout=120,
        )

    def assert_ok(self, result: subprocess.CompletedProcess[str]) -> None:
        self.assertEqual(
            result.returncode,
            0,
            msg=f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}",
        )

    def assert_fail(
        self, result: subprocess.CompletedProcess[str], needle: str = ""
    ) -> None:
        self.assertNotEqual(
            result.returncode,
            0,
            msg=f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}",
        )
        if needle:
            self.assertIn(needle.lower(), result.stderr.lower())

    def encrypt(
        self,
        src: Path,
        dst: Path,
        *extra: object,
        password: str = PASSWORD,
    ) -> subprocess.CompletedProcess[str]:
        return self.run_cli(
            "encrypt",
            src,
            "-o",
            dst,
            "--chunk-size",
            "64K",
            "--force",
            "--password-env",
            PASSWORD_ENV,
            *extra,
            password=password,
        )

    def decrypt(
        self,
        src: Path,
        dst: Path,
        *extra: object,
        password: str = PASSWORD,
    ) -> subprocess.CompletedProcess[str]:
        return self.run_cli(
            "decrypt",
            src,
            "-o",
            dst,
            "--force",
            "--password-env",
            PASSWORD_ENV,
            *extra,
            password=password,
        )

    # ------------------------------------------------------------------

    def test_roundtrip_various_sizes_multichunk(self) -> None:
        cases = {
            "empty": b"",
            "one": b"\x00",
            "under_chunk": b"fox" * 20_000,
            "exact_chunk": bytes(range(256)) * 256,  # 65536
            "over_chunk": bytes(range(256)) * 256 + b"x",
            "multi_chunk": bytes(range(256)) * (1024 * 3 + 17),
        }
        for label, data in cases.items():
            with self.subTest(label=label):
                src = self.dir / f"{label}.bin"
                fox = self.dir / f"{label}.bin.fox"
                out = self.dir / f"{label}.out"
                src.write_bytes(data)

                self.assert_ok(self.encrypt(src, fox))
                self.assertTrue(fox.is_file())
                if os.name != "nt":
                    self.assertEqual(stat.S_IMODE(fox.stat().st_mode), 0o600)
                self.assert_ok(self.decrypt(fox, out))
                self.assertEqual(out.read_bytes(), data)
                if os.name != "nt":
                    self.assertEqual(stat.S_IMODE(out.stat().st_mode), 0o600)

                # Ciphertext tidak boleh sama dengan plaintext.
                self.assertNotEqual(fox.read_bytes(), data)

    def test_chacha20_and_keyfile(self) -> None:
        src = self.dir / "rahasia.txt"
        fox = self.dir / "rahasia.fox"
        out = self.dir / "rahasia.out"
        key = self.dir / "fox.key"
        wrong_key = self.dir / "wrong.key"
        data = ("data rahasia 🦊\n" * 5000).encode()
        src.write_bytes(data)
        key.write_bytes(os.urandom(64))
        wrong_key.write_bytes(os.urandom(64))

        self.assert_ok(
            self.encrypt(
                src,
                fox,
                "--cipher",
                "chacha20poly1305",
                "--keyfile",
                key,
            )
        )

        # Tanpa keyfile harus ditolak sebelum dekripsi.
        missing = self.run_cli("decrypt", fox, "-o", self.dir / "missing")
        self.assert_fail(missing, "--keyfile")

        # Keyfile salah -> tag GCM/Poly1305 gagal.
        wrong_out = self.dir / "wrong.out"
        bad = self.decrypt(fox, wrong_out, "--keyfile", wrong_key)
        self.assert_fail(bad, "password/keyfile salah")
        self.assertFalse(wrong_out.exists())

        self.assert_ok(self.decrypt(fox, out, "--keyfile", key))
        self.assertEqual(out.read_bytes(), data)

        # File tanpa keyfile tidak boleh diberi --keyfile.
        no_key_fox = self.dir / "nokey.fox"
        self.assert_ok(self.encrypt(src, no_key_fox))
        extra = self.run_cli(
            "decrypt", no_key_fox, "-o", self.dir / "extra.out", "--keyfile", key
        )
        self.assert_fail(extra, "tidak memakai keyfile")

    def test_wrong_password_does_not_create_output(self) -> None:
        src = self.dir / "secret.txt"
        fox = self.dir / "secret.fox"
        out = self.dir / "secret.out"
        src.write_bytes(b"jangan sampai bocor" * 1000)

        self.assert_ok(self.encrypt(src, fox))
        result = self.decrypt(fox, out, password="wrong password 123456")
        self.assert_fail(result, "password/keyfile salah")
        self.assertFalse(out.exists())

        # --force tidak boleh menghapus output lama sebelum dekripsi sukses.
        out.write_bytes(b"OUTPUT LAMA")
        result = self.decrypt(fox, out, password="wrong password 123456")
        self.assert_fail(result, "password/keyfile salah")
        self.assertEqual(out.read_bytes(), b"OUTPUT LAMA")

    def test_tamper_truncate_append_and_header(self) -> None:
        data = os.urandom(200_000)
        src = self.dir / "data.bin"
        fox = self.dir / "data.fox"
        src.write_bytes(data)
        self.assert_ok(self.encrypt(src, fox))
        original = fox.read_bytes()

        variants = {
            "tamper": original[:-1] + bytes([original[-1] ^ 0x01]),
            "truncate": original[:-1],
            "append": original + b"X",
            "header": bytes([original[0] ^ 0x01]) + original[1:],
        }
        for label, blob in variants.items():
            with self.subTest(label=label):
                bad_fox = self.dir / f"bad-{label}.fox"
                bad_out = self.dir / f"bad-{label}.out"
                bad_fox.write_bytes(blob)
                result = self.decrypt(bad_fox, bad_out)
                self.assert_fail(result)
                self.assertFalse(bad_out.exists())

    def test_overwrite_protection_and_force(self) -> None:
        src = self.dir / "note.txt"
        fox = self.dir / "note.fox"
        out = self.dir / "note.out"
        src.write_bytes(b"isi asli")
        self.assert_ok(self.encrypt(src, fox))

        out.write_bytes(b"JANGAN DITIMPA")
        result = self.run_cli("decrypt", fox, "-o", out)
        self.assert_fail(result, "--force")
        self.assertEqual(out.read_bytes(), b"JANGAN DITIMPA")

        self.assert_ok(self.decrypt(fox, out))
        self.assertEqual(out.read_bytes(), b"isi asli")

        # Enkripsi juga harus menolak output yang sudah ada.
        existing_fox = self.dir / "existing.fox"
        existing_fox.write_bytes(b"lama")
        result = self.run_cli(
            "encrypt",
            src,
            "-o",
            existing_fox,
            "--password-env",
            PASSWORD_ENV,
        )
        self.assert_fail(result, "--force")
        self.assertEqual(existing_fox.read_bytes(), b"lama")

    def test_same_input_output_rejected(self) -> None:
        src = self.dir / "same.txt"
        src.write_bytes(b"test")
        result = self.run_cli(
            "encrypt",
            src,
            "-o",
            src,
            "--password-env",
            PASSWORD_ENV,
        )
        self.assert_fail(result, "tidak boleh sama")
        self.assertEqual(src.read_bytes(), b"test")

    def test_short_password_rejected(self) -> None:
        src = self.dir / "short.txt"
        fox = self.dir / "short.fox"
        src.write_bytes(b"test")
        result = self.encrypt(src, fox, password="pendek")
        self.assert_fail(result, "minimal 12")
        self.assertFalse(fox.exists())

    def test_info_and_sha256(self) -> None:
        src = self.dir / "info.txt"
        fox = self.dir / "info.fox"
        data = b"informasi file" * 100
        src.write_bytes(data)
        self.assert_ok(self.encrypt(src, fox))

        info = self.run_cli("info", fox)
        self.assert_ok(info)
        self.assertIn("FoxCrypt v1", info.stdout)
        self.assertIn("AES-256-GCM", info.stdout)
        self.assertIn("scrypt", info.stdout)
        self.assertIn("Plaintext", info.stdout)

        digest = self.run_cli("sha256", src)
        self.assert_ok(digest)
        self.assertIn(hashlib.sha256(data).hexdigest(), digest.stdout)

    def test_default_encrypt_extension_and_password_stdin(self) -> None:
        src = self.dir / "default.txt"
        src.write_bytes(b"default path" * 500)
        result = self.run_cli(
            "encrypt",
            src,
            "--password-stdin",
            stdin=PASSWORD + "\n",
        )
        self.assert_ok(result)
        fox = Path(str(src) + ".fox")
        self.assertTrue(fox.is_file())

        # Pindahkan plaintext agar output default (tanpa .fox) bisa dibuat.
        src.unlink()
        result = self.run_cli(
            "decrypt",
            fox,
            "--password-stdin",
            stdin=PASSWORD + "\n",
        )
        self.assert_ok(result)
        self.assertTrue(src.is_file())
        self.assertEqual(src.read_bytes(), b"default path" * 500)


if __name__ == "__main__":
    unittest.main(verbosity=2)
