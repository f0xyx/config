#!/usr/bin/env python3
"""Tes operasi batch, verifikasi, dan shred (tanpa GUI)."""

from __future__ import annotations

import os
import stat
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from foxcrypt import decrypt_file
from foxcrypt_ops import (
    BatchConfig,
    DriveInfo,
    OperationError,
    collect_files,
    encrypt_one,
    run_batch,
    shred_file,
)

PASSWORD = "correct horse battery staple 2026"


class OpsTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.dir = Path(self.temp.name)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_collect_files_filters_and_skips(self) -> None:
        (self.dir / "a.txt").write_bytes(b"a")
        (self.dir / "b.fox").write_bytes(b"b")
        (self.dir / ".foxcrypt-temp.tmp").write_bytes(b"tmp")
        nested = self.dir / "nested"
        nested.mkdir()
        (nested / "c.bin").write_bytes(b"c")
        system = self.dir / "System Volume Information"
        system_created = True
        try:
            system.mkdir()
            (system / "hidden.dat").write_bytes(b"hidden")
        except OSError:
            system_created = False

        files, errors, canceled = collect_files(
            self.dir, operation="encrypt"
        )
        self.assertFalse(canceled)
        self.assertEqual(errors, [])
        names = {path.name for path in files}
        self.assertEqual(names, {"a.txt", "c.bin"})
        if system_created:
            self.assertNotIn("hidden.dat", names)

        fox_files, errors, canceled = collect_files(
            self.dir, operation="decrypt"
        )
        self.assertFalse(canceled)
        self.assertEqual(errors, [])
        self.assertEqual([path.name for path in fox_files], ["b.fox"])

    def test_shred_removes_file(self) -> None:
        target = self.dir / "hapus.bin"
        target.write_bytes(os.urandom(256 * 1024))
        shred_file(target, passes=1)
        self.assertFalse(target.exists())
        leftovers = [
            path.name
            for path in self.dir.iterdir()
            if path.name.startswith(".foxcrypt-")
        ]
        self.assertEqual(leftovers, [])

    def test_shred_refuses_symlink(self) -> None:
        if not hasattr(os, "symlink"):
            self.skipTest("symlink tidak didukung")
        real = self.dir / "real.bin"
        real.write_bytes(b"jangan dihapus")
        link = self.dir / "link.bin"
        try:
            link.symlink_to(real)
        except OSError:
            self.skipTest("tidak bisa membuat symlink")
        with self.assertRaises(OperationError):
            shred_file(link, passes=1)
        self.assertTrue(real.exists())
        self.assertTrue(link.is_symlink())

    def test_shred_refuses_hardlink(self) -> None:
        if not hasattr(os, "link"):
            self.skipTest("hardlink tidak didukung")
        target = self.dir / "hardlink.bin"
        target.write_bytes(b"data hardlink" * 100)
        linked = self.dir / "linked.bin"
        try:
            os.link(target, linked)
        except OSError:
            self.skipTest("tidak bisa membuat hardlink")
        with self.assertRaises(OperationError):
            shred_file(target, passes=1)
        self.assertTrue(target.exists())
        self.assertTrue(linked.exists())
        self.assertEqual(linked.read_bytes(), b"data hardlink" * 100)

    def test_verified_encrypt_then_shred(self) -> None:
        src = self.dir / "rahasia.bin"
        data = (bytes(range(256)) * 4600) + b"ekor"  # > 1 MiB
        src.write_bytes(data)
        outcome = encrypt_one(
            src,
            password=PASSWORD,
            keyfile_digest=None,
            shred_original=True,
            verify_passes=2,
            shred_passes=1,
        )
        self.assertTrue(outcome.ok, outcome.message)
        self.assertTrue(outcome.shredded)
        self.assertFalse(src.exists())
        fox = Path(outcome.dst or "")
        self.assertTrue(fox.is_file())

        restored = self.dir / "restored.bin"
        size = decrypt_file(fox, restored, PASSWORD)
        self.assertEqual(size, len(data))
        self.assertEqual(restored.read_bytes(), data)

    def test_verification_failure_keeps_original(self) -> None:
        src = self.dir / "tetap-ada.bin"
        src.write_bytes(os.urandom(80 * 1024))
        with patch(
            "foxcrypt_ops.decrypt_file",
            side_effect=OperationError("simulasi verifikasi gagal"),
        ):
            outcome = encrypt_one(
                src,
                password=PASSWORD,
                keyfile_digest=None,
                shred_original=True,
                verify_passes=1,
                shred_passes=1,
            )
        self.assertFalse(outcome.ok)
        self.assertTrue(src.exists())
        self.assertTrue((self.dir / "tetap-ada.bin.fox").exists())

    def test_batch_file_mode_does_not_audit_unselected(self) -> None:
        selected = self.dir / "pilih.txt"
        other = self.dir / "jangan.txt"
        selected.write_bytes(b"pilih aku")
        other.write_bytes(b"jangan sentuh")
        result = run_batch(
            BatchConfig(
                operation="encrypt",
                target=self.dir,
                password=PASSWORD,
                mode="file",
                files=[selected],
                shred_originals=True,
                verify_passes=1,
                shred_passes=1,
            )
        )
        self.assertTrue(result.success, result.audit_errors)
        self.assertFalse(selected.exists())
        self.assertTrue((self.dir / "pilih.txt.fox").exists())
        self.assertEqual(other.read_bytes(), b"jangan sentuh")

    def test_parallel_workers_progress_and_outputs(self) -> None:
        sources = []
        for index in range(4):
            path = self.dir / f"parallel-{index}.txt"
            path.write_bytes(f"file {index}\n".encode() * 100)
            sources.append(path)

        events: list[tuple[str, dict]] = []
        result = run_batch(
            BatchConfig(
                operation="encrypt",
                target=self.dir,
                password=PASSWORD,
                mode="file",
                files=sources,
                shred_originals=False,
                verify_passes=1,
                workers=4,
            ),
            on_event=lambda kind, data: events.append((kind, data)),
        )
        self.assertTrue(result.success, result.audit_errors)
        self.assertEqual(result.total, 4)
        for source in sources:
            self.assertTrue(source.exists())
            self.assertTrue(Path(str(source) + ".fox").exists())
        completed = [
            int(data["completed"])
            for kind, data in events
            if kind == "file_done"
        ]
        self.assertEqual(completed, [1, 2, 3, 4])

    def test_worker_limit_validation(self) -> None:
        source = self.dir / "limit.txt"
        source.write_bytes(b"limit")
        result = run_batch(
            BatchConfig(
                operation="encrypt",
                target=self.dir,
                password=PASSWORD,
                mode="file",
                files=[source],
                workers=101,
            )
        )
        self.assertFalse(result.success)
        self.assertTrue(any("Worker" in error for error in result.scan_errors))

    def test_parallel_cancel_stops_new_shred(self) -> None:
        import threading

        sources = []
        for index in range(6):
            path = self.dir / f"cancel-{index}.txt"
            path.write_bytes(os.urandom(20 * 1024))
            sources.append(path)

        cancel_event = threading.Event()
        done_events = 0

        def on_event(kind: str, _data: dict) -> None:
            nonlocal done_events
            if kind == "file_done":
                done_events += 1
                if done_events == 1:
                    cancel_event.set()

        result = run_batch(
            BatchConfig(
                operation="encrypt",
                target=self.dir,
                password=PASSWORD,
                mode="file",
                files=sources,
                shred_originals=True,
                verify_passes=1,
                workers=2,
            ),
            on_event=on_event,
            should_cancel=cancel_event.is_set,
        )
        self.assertTrue(result.canceled)
        self.assertFalse(result.success)
        remaining = [path for path in sources if path.exists()]
        self.assertTrue(remaining, "cancel should leave some originals untouched")

    def test_batch_folder_encrypt_shred_and_audit(self) -> None:
        (self.dir / "satu.txt").write_bytes(b"satu" * 100)
        sub = self.dir / "sub"
        sub.mkdir()
        (sub / "dua.bin").write_bytes(os.urandom(50 * 1024))
        system = self.dir / "System Volume Information"
        system_created = True
        try:
            system.mkdir()
            (system / "jangan.dat").write_bytes(b"system")
        except OSError:
            system_created = False

        result = run_batch(
            BatchConfig(
                operation="encrypt",
                target=self.dir,
                password=PASSWORD,
                mode="folder",
                shred_originals=True,
                verify_passes=1,
                shred_passes=1,
            )
        )
        self.assertTrue(result.success, result.audit_errors)
        self.assertFalse((self.dir / "satu.txt").exists())
        self.assertFalse((sub / "dua.bin").exists())
        self.assertTrue((self.dir / "satu.txt.fox").exists())
        self.assertTrue((sub / "dua.bin.fox").exists())
        if system_created:
            self.assertTrue((system / "jangan.dat").exists())

    def test_batch_drive_mode_with_fake_drive(self) -> None:
        (self.dir / "drive-satu.txt").write_bytes(b"data drive" * 100)
        nested = self.dir / "folder"
        nested.mkdir()
        (nested / "drive-dua.bin").write_bytes(os.urandom(20 * 1024))
        info = DriveInfo(
            root=str(self.dir),
            label="TEST",
            fs="APFS",
            kind="Fixed",
            total=1000000,
            free=500000,
            is_system=False,
        )
        with patch("foxcrypt_ops.is_drive_root", return_value=True), patch(
            "foxcrypt_ops._is_windows_system_root", return_value=False
        ), patch(
            "foxcrypt_ops._drive_info_for_root", return_value=info
        ):
            result = run_batch(
                BatchConfig(
                    operation="encrypt",
                    target=self.dir,
                    password=PASSWORD,
                    mode="drive",
                    shred_originals=True,
                    verify_passes=1,
                    shred_passes=1,
                )
            )
        self.assertTrue(result.success, result.audit_errors)
        self.assertFalse((self.dir / "drive-satu.txt").exists())
        self.assertFalse((nested / "drive-dua.bin").exists())
        self.assertTrue((self.dir / "drive-satu.txt.fox").exists())
        self.assertTrue((nested / "drive-dua.bin.fox").exists())

    def test_batch_decrypt_file_mode(self) -> None:
        src = self.dir / "pulih.txt"
        data = b"data untuk pulih" * 500
        src.write_bytes(data)
        outcome = encrypt_one(
            src,
            password=PASSWORD,
            keyfile_digest=None,
            shred_original=True,
            verify_passes=1,
            shred_passes=1,
        )
        self.assertTrue(outcome.ok, outcome.message)
        self.assertFalse(src.exists())
        fox = Path(outcome.dst or "")

        result = run_batch(
            BatchConfig(
                operation="decrypt",
                target=self.dir,
                password=PASSWORD,
                mode="file",
                files=[fox],
            )
        )
        self.assertTrue(result.success, result.audit_errors)
        self.assertTrue(src.exists())
        self.assertEqual(src.read_bytes(), data)
        self.assertTrue(fox.exists())

    def test_readonly_file_can_be_shredded(self) -> None:
        target = self.dir / "readonly.bin"
        target.write_bytes(b"readonly" * 100)
        os.chmod(target, stat.S_IREAD)
        shred_file(target, passes=1)
        self.assertFalse(target.exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
