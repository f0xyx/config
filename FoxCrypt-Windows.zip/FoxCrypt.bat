@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title FoxCrypt

where py >nul 2>nul
if not errorlevel 1 (
    py -3 launcher.py
    if errorlevel 1 (
        echo.
        echo FoxCrypt gagal dijalankan. Periksa pesan di atas.
        pause
        exit /b 1
    )
    exit /b 0
)

where python >nul 2>nul
if not errorlevel 1 (
    python launcher.py
    if errorlevel 1 (
        echo.
        echo FoxCrypt gagal dijalankan. Periksa pesan di atas.
        pause
        exit /b 1
    )
    exit /b 0
)

echo Python 3 tidak ditemukan.
echo.
echo Instal Python 3.10 atau lebih baru dari:
echo   https://www.python.org/downloads/windows/
echo.
echo Saat instalasi, centang "Add Python to PATH".
echo Setelah itu jalankan FoxCrypt.bat lagi.
echo.
start "" "https://www.python.org/downloads/windows/"
pause
exit /b 1
