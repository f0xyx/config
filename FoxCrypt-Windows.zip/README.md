# FoxCrypt v1 — enkripsi file & drive

Enkripsi file-level dengan **AES-256-GCM** (default) atau
**ChaCha20-Poly1305**, kunci diturunkan dari password memakai **scrypt**
dan **HKDF-SHA256**. Tersedia GUI tkinter, CLI, dan mode batch untuk
memproses seluruh drive non-sistem.

> **Baca dulu:** FoxCrypt tidak bisa menjamin 100% bahwa file asli yang
> sudah dihapus tidak dapat dipulihkan. Pada SSD/NVMe, APFS, NTFS,
> snapshot, journal, dan cloud sync, salinan lama bisa tertinggal.
> Untuk jaminan penuh gunakan BitLocker/VeraCrypt, ATA Secure Erase, atau
> pemusnahan media. Detail ada di bagian **Shred & recovery**.

---

## Windows — quick start

1. Instal **Python 3.10+ 64-bit** dari
   <https://www.python.org/downloads/windows/>.
   Centang **Add Python to PATH**. Installer python.org sudah menyertakan
   tkinter.
2. Salin folder `foxcrypt` ke Windows (boleh di mana saja).
3. Klik dua kali **`FoxCrypt.bat`**.
4. Run pertama akan otomatis:
   - membuat virtualenv `.venv-win`,
   - memasang `cryptography` dari `requirements.txt`,
   - memeriksa tkinter,
   - membuka GUI.
5. Jika Python tidak ditemukan, batch file akan menampilkan link unduhan.

Run pertama membutuhkan koneksi internet untuk mengunduh `cryptography`.
Run berikutnya tidak perlu install ulang selama `.venv-win` masih ada.

`FoxCrypt.bat` menjalankan `launcher.py`. Dependency Python yang
dipasang otomatis adalah `cryptography`; Python dan tkinter adalah
prasyarat sistem. Tidak perlu menjalankan pip manual.

Untuk pengujian pertama, gunakan folder kecil, bukan seluruh drive.

CLI di Windows (dependency tetap otomatis):

```bat
FoxCryptCLI.bat encrypt D:\data\laporan.pdf
FoxCryptCLI.bat decrypt D:\data\laporan.pdf.fox
FoxCryptCLI.bat info D:\data\laporan.pdf.fox
```

---

## GUI

### Tab Enkripsi

- **Drive:** pilih C:, D:, USB, dsb.
- **Target:**
  - **Seluruh drive** — semua file non-sistem di drive itu.
  - **Folder** — semua file di folder itu secara rekursif.
  - **File** — pilih satu/beberapa file.
- **Password:** minimal 12 karakter. Saat enkripsi harus diketik dua kali.
- **Keyfile (opsional):** faktor kedua. File keyfile yang sama wajib
  dipakai saat dekripsi.
- **Verifikasi decrypt:** 1–3 pass. Default 2 pass. Setiap pass
  mendekripsi ciphertext, lalu membandingkan SHA-256 dengan file asli.
- **Pass shred:** 1–5 pass overwrite. Default 1.
- **Hapus file asli:** hanya dijalankan setelah hash + verifikasi decrypt
  lolos. Jika tidak dicentang, file asli dipertahankan.

### Tab Dekripsi

- Pilih drive/folder/file `.fox`.
- Hasil dekripsi memakai nama asli (ekstensi `.fox` dibuang).
- File yang sudah ada **tidak ditimpa**; file tersebut dilaporkan sebagai
  skip/gagal agar tidak menghilangkan data.
- File `.fox` tetap disimpan setelah dekripsi.

### Mode seluruh drive

Hanya untuk **drive non-sistem**. Drive C:/drive yang berisi Windows
ditolak. Sebelum mulai, GUI meminta Anda:

- mencentang pernyataan backup,
- mengetik frasa konfirmasi, mis. `ENKRIPSI D:`.

Yang dilewati otomatis:

- folder sistem (`System Volume Information`, `$RECYCLE.BIN`, dll.),
- file sistem/metadata Windows,
- symlink, junction, reparse point/mount point (termasuk placeholder
  cloud seperti OneDrive),
- file `.fox` yang sudah ada,
- file sementara FoxCrypt,
- folder aplikasi FoxCrypt sendiri (agar program tidak menghapus dirinya).

**Aplikasi, game, dan data lain di drive target akan berhenti berfungsi**
sampai file-nya didekripsi. Jangan mengenkripsi drive berisi Windows,
program yang sedang dipakai, atau satu-satunya salinan data penting.

Setiap file memakai scrypt (~0,3–0,5 detik di mesin modern) ditambah
verifikasi decrypt. Drive dengan puluhan ribu file bisa memakan
berjam-jam; ini konsekuensi KDF per file, bukan hang.

---

## Verifikasi sebelum “selesai”

Untuk setiap file enkripsi, urutannya:

1. File dienkripsi ke `nama.ext.fox` secara atomik.
2. Header `.fox` dicek terhadap ukuran file asli.
3. File asli dibaca ulang dan di-hash; jika berubah selama enkripsi,
   proses file itu digagalkan dan **file asli tidak disentuh**.
4. Ciphertext didekripsi ulang 1–3 pass ke file sementara.
5. Setiap hasil decrypt dibandingkan ukuran + **SHA-256** dengan file asli.
6. Hanya jika semua pass lolos, file asli di-shred (opsional).
7. Setelah semua file, audit akhir:
   - output `.fox` harus ada dan header-nya valid,
   - tidak boleh ada file eligible yang tersisa (jika shred diminta),
   - tidak boleh ada file sementara tertinggal,
   - scan error membuat status bukan sukses penuh.

Status **“Selesai & terverifikasi”** hanya muncul jika tidak ada file
gagal/skip dan audit bersih. Jika ada satu saja masalah, GUI menampilkan
**“Selesai sebagian — periksa log”**, bukan “done”.

Shred tidak dijalankan jika:
- verifikasi gagal,
- file asli berubah,
- file memiliki hardlink (agar link lain tidak ikut rusak),
- file terkunci/tidak bisa dibuka,
- file berubah menjadi symlink/reparse point.

Jika shred gagal/partial, ciphertext `.fox` sudah terverifikasi dan tetap
disimpan. Jangan hapus `.fox` tersebut; data masih bisa dipulihkan dengan
`foxcrypt decrypt` atau tab Dekripsi selama password/keyfile tersedia.

---

## Shred & recovery — batasan penting

“Shred” di sini berarti **best-effort**:

1. overwrite file dengan data acak beberapa pass,
2. `fsync`,
3. truncate ke 0,
4. rename ke nama acak,
5. hapus,
6. cek path asli sudah tidak ada.

Satu pass overwrite random umumnya cukup untuk menimpa data secara
logis di HDD; menambah pass tidak memperbaiki jaminan di SSD. Ini
**bukan jaminan fisik**. Data bisa masih ada di:

- blok bebas/wear-leveling SSD/NVMe (TRIM tidak selalu langsung),
- copy-on-write/snapshot APFS, Btrfs, ZFS, Windows Volume Shadow Copy,
- NTFS **alternate data streams**, USN journal, MFT,
- pagefile/hiberfil, crash dump, recycle bin,
- backup, cloud sync, email, aplikasi yang membuka file,
- hardlink atau copy lain.

Untuk data yang benar-benar sensitif:

- gunakan **full-disk encryption** (BitLocker/VeraCrypt) sejak awal,
- gunakan **ATA Secure Erase** atau fitur secure erase vendor SSD,
- atau musnahkan media secara fisik.

FoxCrypt hanya alat file-level; **bukan full-disk encryption** dan belum
diaudit secara independen.

---

## CLI

```bash
cd ~/foxcrypt
./foxcrypt --help

# Enkripsi: data.pdf -> data.pdf.fox
./foxcrypt encrypt data.pdf

# Dekripsi
./foxcrypt decrypt data.pdf.fox -o data.restored.pdf

# Keyfile
./foxcrypt encrypt backup.tar.gz --keyfile ~/.keys/fox.key
./foxcrypt decrypt backup.tar.gz.fox --keyfile ~/.keys/fox.key

# Info / hash
./foxcrypt info data.pdf.fox
./foxcrypt sha256 data.pdf.fox

# Non-interaktif (hindari password di argv)
FOX_PASS='password-panjang-sekali' ./foxcrypt encrypt data.txt --password-env FOX_PASS
./foxcrypt decrypt data.txt.fox --password-file ~/.fox.pass
printf '%s\n' 'password-panjang-sekali' | ./foxcrypt encrypt data.txt --password-stdin
```

CLI tidak menghapus file asli. Penghapusan hanya ada di GUI/opsi batch.
Minimal password enkripsi 12 karakter. Opsi cipher:
`--cipher aes256gcm` (default) atau `--cipher chacha20poly1305`.
`--chunk-size` 64 KiB–16 MiB, default 1 MiB.

### Instalasi manual (macOS/Linux)

```bash
cd ~/foxcrypt
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
chmod +x foxcrypt foxcrypt.py
ln -sf ~/foxcrypt/foxcrypt ~/.local/bin/foxcrypt
```

GUI:

```bash
.venv/bin/python launcher.py
```

Di macOS Homebrew, tkinter mungkin perlu `brew install python-tk`.
Di Linux: `sudo apt install python3-tk`.

---

## Desain kriptografi

```text
password (NFC UTF-8) + keyfile opsional
        │
        ├── SHA-256 (pemisahan domain password/keyfile)
        ▼
scrypt  N=2^17 (131072), r=8, p=1, salt 32 byte acak
        │  (~128 MiB RAM, memory-hard)
        ▼
HKDF-SHA256  info="FOXCRYPT-v1-file-encryption-key"
        │
        ▼
key 256-bit ──► AES-256-GCM / ChaCha20-Poly1305
```

- **SHA-256 bukan enkripsi.** SHA-256 adalah hash satu arah. Di sini
  SHA-256 dipakai di KDF dan verifikasi; kerahasiaan berasal dari AEAD.
- Salt 256-bit acak per file; kunci berbeda walaupun password sama.
- Nonce per chunk = prefix acak 64-bit + counter 32-bit; counter masuk AAD.
- Header diautentikasi sebagai AAD di setiap chunk.
- Setiap chunk punya authentication tag 128-bit.
- Frame final + cek EOF mendeteksi truncation dan data tambahan.
- Output ditulis atomik dengan mode `0600` (POSIX), `fsync`, lalu rename.
  Di Windows, ACL file mengikuti folder tujuan; gunakan folder pribadi
  jika ada user lain di mesin. File `.fox` sendiri tetap ciphertext.
- Password minimal 12 karakter; gunakan password manager/passphrase.

### Format `.fox` v1

Header 76 byte, semua integer big-endian:

| Offset | Ukuran | Isi |
|---:|---:|---|
| 0 | 8 | magic `FOXFILE1` |
| 8 | 1 | versi = `1` |
| 9 | 1 | cipher: `1` AES-256-GCM, `2` ChaCha20-Poly1305 |
| 10 | 1 | KDF: `1` scrypt |
| 11 | 1 | `log2(N)` scrypt (default 17) |
| 12 | 4 | `r` (default 8) |
| 16 | 4 | `p` (default 1) |
| 20 | 32 | salt acak |
| 52 | 8 | prefix nonce |
| 60 | 4 | ukuran chunk |
| 64 | 4 | flags: bit 0 = butuh keyfile |
| 68 | 8 | ukuran plaintext |

Frame:

| Ukuran | Isi |
|---:|---|
| 4 | panjang plaintext chunk |
| 4 | nomor chunk |
| 1 | final (0/1) |
| `plaintext_len` | ciphertext |
| 16 | tag |

`AAD = header || frame_header`; nonce = `prefix || counter`.
Chunk non-final selalu penuh; chunk final boleh lebih pendek/0.

---

## Batasan

- Bukan pengganti full-disk encryption. Gunakan FileVault/BitLocker juga.
- Keamanan bergantung pada password/keyfile. Password lemah bisa
  di-brute-force offline.
- Tidak ada recovery password. Kehilangan password/keyfile = data hilang.
- File asli tidak dihapus oleh CLI; GUI hanya menghapus jika dicentang dan
  verifikasi lolos.
- Shred best-effort; lihat bagian **Shred & recovery**.
- Proses yang dikompromikan (malware/keylogger/memory dump) bisa mencuri
  password/kunci saat dipakai. Python tidak bisa menjamin wipe memori.
- Metadata tetap terlihat: ukuran file, waktu, nama path, dan header `.fox`.
- Belum diaudit independen. Untuk data sangat penting, gunakan tools
  mapan yang sudah diaudit selain/ketimbang implementasi ini.
- Jalur Windows sudah diimplementasikan dengan fallback (ctypes,
  `os.replace`, reparse point, drive enumeration), tetapi verifikasi akhir
  pada mesin Windows fisik tetap disarankan sebelum memproses drive nyata.

---

## Tes

Windows:

```bat
cd /d path\ke\foxcrypt
.venv-win\Scripts\python -m unittest -v test_foxcrypt.py test_ops.py
```

macOS/Linux:

```bash
cd ~/foxcrypt
.venv/bin/python -m unittest -v test_foxcrypt.py test_ops.py
```

Cakupan:

- round-trip berbagai ukuran/chunk, AES & ChaCha, keyfile,
- password salah, tampering, truncation, trailing data,
- overwrite protection, info, sha256,
- collect/filter drive, symlink skip,
- verifikasi decrypt + SHA-256,
- shred + audit,
- mode file/folder batch, kegagalan verifikasi tidak menghapus asli.

GUI diuji dengan tkinter di macOS (instansiasi dan alur enkripsi,
shred, dekripsi folder). Tetap lakukan uji coba pada folder kecil di
Windows sebelum memakai mode drive.
