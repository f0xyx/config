#!/usr/bin/env python3
"""
FoxCrypt GUI (tkinter).

Fokus utama: Windows. GUI memilih drive/folder/file, melakukan enkripsi
atau dekripsi, memverifikasi ciphertext dengan decrypt ulang, lalu
melakukan best-effort shred hanya setelah verifikasi berhasil.
"""

from __future__ import annotations

import hmac
import os
import queue
import sys
import threading
import traceback
import unicodedata
from pathlib import Path

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, scrolledtext, ttk
except ImportError:
    message = (
        "tkinter tidak tersedia. Di Windows, instal Python dari python.org "
        "(tkinter sudah termasuk). Di Linux: sudo apt install python3-tk. "
        "Di macOS Homebrew: brew install python-tk."
    )
    if sys.stderr is not None:
        print(message, file=sys.stderr)
    raise SystemExit(1)

from foxcrypt import MIN_PASSWORD_LEN, hash_keyfile
from foxcrypt_ops import (
    APP_ROOT,
    BatchConfig,
    BatchResult,
    DriveInfo,
    FileOutcome,
    format_bytes,
    is_drive_root,
    list_drives,
    run_batch,
)


APP_TITLE = "FoxCrypt 1.0 — Enkripsi File & Drive"
PASSWORD_MIN = MIN_PASSWORD_LEN


class ScrollableFrame(ttk.Frame):
    """Tab yang bisa di-scroll, supaya tetap muat di layar 1366x768."""

    def __init__(self, parent: tk.Misc, *, height: int = 400) -> None:
        super().__init__(parent)
        self.canvas = tk.Canvas(
            self,
            highlightthickness=0,
            height=height,
            borderwidth=0,
        )
        self.canvas.pack(side="left", fill="both", expand=True)

        scrollbar = ttk.Scrollbar(
            self, orient="vertical", command=self.canvas.yview
        )
        scrollbar.pack(side="right", fill="y")
        self.canvas.configure(yscrollcommand=scrollbar.set)

        self.inner = ttk.Frame(self.canvas, padding=10)
        self._window = self.canvas.create_window(
            (0, 0), window=self.inner, anchor="nw"
        )
        self.inner.bind("<Configure>", self._on_inner_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        self.canvas.bind("<MouseWheel>", self._on_mousewheel)
        self.inner.bind("<MouseWheel>", self._on_mousewheel)

    def _on_inner_configure(self, _event: tk.Event | None = None) -> None:
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, event: tk.Event) -> None:
        self.canvas.itemconfigure(self._window, width=event.width)

    def _on_mousewheel(self, event: tk.Event) -> None:
        delta = int(-event.delta / 120) if event.delta else 0
        if delta == 0:
            delta = -1 if event.delta > 0 else 1
        self.canvas.yview_scroll(delta, "units")


class TargetPanel(ttk.LabelFrame):
    def __init__(
        self,
        parent: tk.Misc,
        app: "FoxCryptApp",
        *,
        operation: str,
        title: str,
    ) -> None:
        super().__init__(parent, text=title, padding=10)
        self.app = app
        self.operation = operation
        self.drives: list[DriveInfo] = []
        self._drive_by_display: dict[str, DriveInfo] = {}
        self._files: list[Path] = []

        self.drive_var = tk.StringVar()
        self.mode_var = tk.StringVar(value="folder")
        self.path_var = tk.StringVar()
        self.info_var = tk.StringVar(value="Pilih drive/folder/file.")

        self.columnconfigure(1, weight=1)

        ttk.Label(self, text="Drive:").grid(
            row=0, column=0, sticky="w", padx=(0, 8), pady=3
        )
        self.drive_combo = ttk.Combobox(
            self, textvariable=self.drive_var, state="readonly", width=44
        )
        self.drive_combo.grid(row=0, column=1, sticky="ew", pady=3)
        self.drive_combo.bind("<<ComboboxSelected>>", self._on_drive_selected)

        self.refresh_btn = ttk.Button(
            self, text="Refresh", command=app.refresh_drives, width=10
        )
        self.refresh_btn.grid(row=0, column=2, padx=(6, 0), pady=3)

        mode_frame = ttk.Frame(self)
        mode_frame.grid(row=1, column=0, columnspan=3, sticky="w", pady=(4, 0))
        ttk.Label(mode_frame, text="Target:").pack(side="left", padx=(0, 8))
        for label, value in (
            ("Seluruh drive", "drive"),
            ("Folder", "folder"),
            ("File", "file"),
        ):
            ttk.Radiobutton(
                mode_frame,
                text=label,
                value=value,
                variable=self.mode_var,
                command=self._on_mode_changed,
            ).pack(side="left", padx=(0, 8))

        self.path_entry = ttk.Entry(self, textvariable=self.path_var)
        self.path_entry.grid(row=2, column=1, sticky="ew", pady=3)
        ttk.Label(self, text="Path:").grid(
            row=2, column=0, sticky="w", padx=(0, 8), pady=3
        )
        self.browse_btn = ttk.Button(
            self, text="Pilih...", command=self._browse, width=10
        )
        self.browse_btn.grid(row=2, column=2, padx=(6, 0), pady=3)

        self.info_label = ttk.Label(
            self,
            textvariable=self.info_var,
            foreground="#555555",
            wraplength=760,
        )
        self.info_label.grid(
            row=3, column=0, columnspan=3, sticky="w", pady=(4, 0)
        )

        self._on_mode_changed()

    # ------------------------------------------------------------------

    def selected_drive(self) -> DriveInfo | None:
        return self._drive_by_display.get(self.drive_var.get())

    def refresh_drives(self, drives: list[DriveInfo]) -> None:
        current_root = None
        info = self.selected_drive()
        if info is not None:
            current_root = info.root

        self.drives = drives
        self._drive_by_display = {item.display(): item for item in drives}
        displays = list(self._drive_by_display)
        self.drive_combo["values"] = displays
        if not displays:
            self.drive_var.set("")
            self.info_var.set("Tidak ada drive yang terdeteksi.")
            return

        chosen = None
        if current_root is not None:
            for item in drives:
                if item.root == current_root:
                    chosen = item
                    break
        if chosen is None:
            for item in drives:
                if not item.is_system:
                    chosen = item
                    break
        if chosen is None:
            chosen = drives[0]

        self.drive_var.set(chosen.display())
        self._update_drive_info()
        if self.mode_var.get() == "drive":
            self.path_var.set(chosen.root)

    def _on_drive_selected(self, _event: tk.Event | None = None) -> None:
        self._update_drive_info()
        if self.mode_var.get() == "drive":
            info = self.selected_drive()
            if info is not None:
                self.path_var.set(info.root)

    def _update_drive_info(self) -> None:
        info = self.selected_drive()
        if info is None:
            self.info_var.set("Pilih drive.")
            return
        system = " — DRIVE SISTEM, TIDAK DIIZINKAN" if info.is_system else ""
        self.info_var.set(
            f"{info.root} [{info.label or info.kind}] "
            f"{format_bytes(info.free)} bebas dari {format_bytes(info.total)}"
            f"{system}"
        )
        if info.is_system:
            self.info_label.configure(foreground="#b00020")
        else:
            self.info_label.configure(foreground="#555555")

    def _on_mode_changed(self) -> None:
        mode = self.mode_var.get()
        if mode == "drive":
            info = self.selected_drive()
            if info is not None:
                self.path_var.set(info.root)
            self.path_entry.configure(state="readonly")
            self.browse_btn.configure(state="disabled")
        elif mode == "folder":
            self.path_entry.configure(state="normal")
            self.browse_btn.configure(state="normal")
        else:
            self.path_entry.configure(state="readonly")
            self.browse_btn.configure(state="normal")
            self._refresh_file_display()

        if mode == "drive":
            if self.operation == "encrypt":
                self.info_var.set(
                    "Semua file non-sistem di drive ini akan dienkripsi. "
                    "File .fox dan folder sistem dilewati."
                )
            else:
                self.info_var.set(
                    "Semua file .fox di drive ini akan didekripsi. "
                    "File yang sudah ada tidak ditimpa."
                )
        elif mode == "folder":
            if self.operation == "encrypt":
                self.info_var.set(
                    "Pilih satu folder. Semua file non-.fox di dalamnya "
                    "diproses rekursif."
                )
            else:
                self.info_var.set(
                    "Pilih satu folder. Semua file .fox di dalamnya "
                    "didekripsi rekursif."
                )
        else:
            if self.operation == "encrypt":
                self.info_var.set("Pilih file yang akan dienkripsi.")
            else:
                self.info_var.set("Pilih file .fox yang akan didekripsi.")

    def _browse(self) -> None:
        mode = self.mode_var.get()
        if mode == "folder":
            initial = self.path_var.get().strip()
            if not initial or not Path(initial).is_dir():
                initial = os.path.expanduser("~")
            selected = filedialog.askdirectory(
                parent=self, initialdir=initial, mustexist=True
            )
            if selected:
                self.path_var.set(selected)
                self.info_var.set(f"Folder: {selected}")
        elif mode == "file":
            if self.operation == "encrypt":
                paths = filedialog.askopenfilenames(
                    parent=self,
                    title="Pilih file yang akan dienkripsi",
                )
            else:
                paths = filedialog.askopenfilenames(
                    parent=self,
                    title="Pilih file .fox yang akan didekripsi",
                    filetypes=[("FoxCrypt", "*.fox"), ("Semua file", "*.*")],
                )
            if paths:
                self._files = [Path(item) for item in paths]
                if self.operation == "decrypt":
                    self._files = [
                        item
                        for item in self._files
                        if item.name.casefold().endswith(".fox")
                    ]
                self._refresh_file_display()

    def _refresh_file_display(self) -> None:
        if self.mode_var.get() != "file":
            return
        if not self._files:
            self.path_var.set("")
            self.info_var.set("Belum ada file dipilih.")
            return
        first = self._files[0]
        more = f" (+{len(self._files) - 1} file lain)" if len(self._files) > 1 else ""
        self.path_var.set(str(first) + more)
        self.info_var.set(f"{len(self._files)} file dipilih.")

    def get_target(self) -> tuple[str, Path, list[Path]]:
        mode = self.mode_var.get()
        if mode == "drive":
            info = self.selected_drive()
            if info is None:
                raise ValueError("Pilih drive terlebih dahulu.")
            return mode, Path(info.root), []
        if mode == "folder":
            text = self.path_var.get().strip()
            if not text:
                raise ValueError("Pilih folder terlebih dahulu.")
            return mode, Path(text), []
        if not self._files:
            raise ValueError("Pilih minimal satu file.")
        return mode, self._files[0].parent, list(self._files)

    def set_busy(self, busy: bool) -> None:
        state = "disabled" if busy else "normal"
        self.drive_combo.configure(state="disabled" if busy else "readonly")
        self.refresh_btn.configure(state=state)
        self.browse_btn.configure(state=state)
        self.path_entry.configure(state="disabled" if busy else "normal")
        for child in self.winfo_children():
            if isinstance(child, ttk.Frame):
                for sub in child.winfo_children():
                    try:
                        if isinstance(sub, ttk.Radiobutton):
                            sub.configure(state=state)
                    except tk.TclError:
                        pass
        if not busy:
            self._on_mode_changed()


class DriveConfirmDialog(tk.Toplevel):
    def __init__(
        self,
        parent: "FoxCryptApp",
        drive: DriveInfo,
        *,
        operation: str,
        shred: bool,
    ) -> None:
        super().__init__(parent)
        self.result = False
        self.phrase = f"{'ENKRIPSI' if operation == 'encrypt' else 'DEKRIPSI'} {drive.letter}:"
        self.title("Konfirmasi drive")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        frame = ttk.Frame(self, padding=16)
        frame.pack(fill="both", expand=True)

        heading = (
            "Anda akan memproses SELURUH DRIVE"
            if operation == "encrypt"
            else "Anda akan mendekripsi seluruh .fox di drive"
        )
        ttk.Label(
            frame,
            text=heading,
            font=("TkDefaultFont", 13, "bold"),
        ).pack(anchor="w")

        lines = [
            f"Drive: {drive.root}  [{drive.label or drive.kind}]",
            f"Bebas: {format_bytes(drive.free)} / {format_bytes(drive.total)}",
            "",
        ]
        if operation == "encrypt":
            lines.extend(
                [
                    "Semua file non-sistem di drive ini akan dienkripsi.",
                    "Folder sistem, aplikasi FoxCrypt/Python, symlink, "
                    "hardlink, dan .fox lama otomatis dikecualikan.",
                    "Ini BUKAN full-disk encryption (BitLocker/VeraCrypt). "
                    "Drive tetap drive biasa; file berubah menjadi .fox.",
                    "Aplikasi/game/data di drive ini akan berhenti berfungsi "
                    "sampai didekripsi. Tutup aplikasi yang memakai drive ini.",
                    "",
                    "Setelah setiap file terverifikasi beberapa kali, file "
                    "asli akan di-shred best-effort. Sediakan ruang bebas "
                    "≈ 2 × (jumlah worker × file terbesar).",
                    "PERINGATAN: shred TIDAK menjamin data tidak bisa "
                    "dipulihkan di SSD/NVMe, snapshot, journal, atau "
                    "alternate data stream. Untuk jaminan fisik, gunakan "
                    "full-disk encryption atau pemusnahan media.",
                ]
            )
            if not shred:
                lines.append("Opsi shred belum dicentang; proses akan ditolak.")
        else:
            lines.extend(
                [
                    "Semua file .fox di drive ini akan didekripsi.",
                    "File hasil dekripsi tidak menimpa file yang sudah ada.",
                ]
            )
        lines.extend(
            [
                "",
                "Setiap file memakai scrypt (~0,3–0,5 detik) ditambah "
                "verifikasi decrypt. Puluhan ribu file bisa memakan "
                "berjam-jam; ini normal, jangan matikan proses.",
                "Jangan matikan komputer atau mencabut drive saat proses.",
                "Backup data penting sebelum melanjutkan.",
            ]
        )
        ttk.Label(
            frame,
            text="\n".join(lines),
            wraplength=640,
            justify="left",
        ).pack(anchor="w", pady=(8, 10))

        self.confirm_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            frame,
            text="Saya sudah backup dan memahami risiko kehilangan data.",
            variable=self.confirm_var,
            command=self._update_ok,
        ).pack(anchor="w", pady=4)

        ttk.Label(
            frame,
            text=f"Ketik '{self.phrase}' untuk mengonfirmasi:",
        ).pack(anchor="w", pady=(10, 2))
        self.phrase_var = tk.StringVar()
        self.entry = ttk.Entry(frame, textvariable=self.phrase_var, width=40)
        self.entry.pack(anchor="w", fill="x")
        self.phrase_var.trace_add("write", lambda *_: self._update_ok())

        button_row = ttk.Frame(frame)
        button_row.pack(fill="x", pady=(16, 0))
        self.ok_btn = ttk.Button(
            button_row, text="Lanjutkan", command=self._ok, state="disabled"
        )
        self.ok_btn.pack(side="right")
        ttk.Button(button_row, text="Batal", command=self._cancel).pack(
            side="right", padx=(0, 8)
        )
        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.after(100, self.entry.focus_set)
        self.wait_window(self)

    def _update_ok(self) -> None:
        ready = self.confirm_var.get() and (
            self.phrase_var.get().strip().upper() == self.phrase
        )
        self.ok_btn.configure(state="normal" if ready else "disabled")

    def _ok(self) -> None:
        self.result = True
        self.destroy()

    def _cancel(self) -> None:
        self.result = False
        self.destroy()


class FoxCryptApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1000x760")
        self.minsize(860, 620)
        self.drives: list[DriveInfo] = []
        self.busy = False
        self.cancel_event = threading.Event()
        self.queue: queue.Queue[tuple[str, object]] = queue.Queue()

        self._build_style()
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.refresh_drives(first=True)
        self._append_log(
            "Selamat datang di FoxCrypt. Pilih target, masukkan password, "
            "lalu mulai. File asli hanya di-shred setelah verifikasi.",
            "info",
        )

    def report_callback_exception(self, exc, val, tb) -> None:
        text = "".join(traceback.format_exception(exc, val, tb))
        try:
            self._append_log(text, "fail")
        except Exception:
            pass
        try:
            messagebox.showerror(
                "FoxCrypt error",
                f"Terjadi error pada GUI:\n\n{val}",
                parent=self,
            )
        except Exception:
            if sys.stderr is not None:
                print(text, file=sys.stderr)

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------

    def _build_style(self) -> None:
        style = ttk.Style(self)
        try:
            if os.name == "nt" and "vista" in style.theme_names():
                style.theme_use("vista")
        except tk.TclError:
            pass

    def _build_ui(self) -> None:
        outer = ttk.Frame(self, padding=12)
        outer.pack(fill="both", expand=True)

        header = ttk.Frame(outer)
        header.pack(fill="x", pady=(0, 8))
        ttk.Label(
            header,
            text="FoxCrypt",
            font=("TkDefaultFont", 20, "bold"),
        ).pack(side="left")
        ttk.Label(
            header,
            text="  AES-256-GCM / ChaCha20-Poly1305 · scrypt + HKDF-SHA256",
            foreground="#555555",
        ).pack(side="left", pady=(8, 0))

        notebook = ttk.Notebook(outer)
        notebook.pack(fill="both", expand=True)

        self.enc_scroll = ScrollableFrame(notebook, height=400)
        self.dec_scroll = ScrollableFrame(notebook, height=400)
        self.enc_tab = self.enc_scroll.inner
        self.dec_tab = self.dec_scroll.inner
        notebook.add(self.enc_scroll, text="  Enkripsi  ")
        notebook.add(self.dec_scroll, text="  Dekripsi  ")

        self._build_encrypt_tab(self.enc_tab)
        self._build_decrypt_tab(self.dec_tab)

        status_frame = ttk.Frame(outer)
        status_frame.pack(fill="x", pady=(8, 0))
        self.status_var = tk.StringVar(value="Siap.")
        ttk.Label(
            status_frame, textvariable=self.status_var, anchor="w"
        ).pack(side="left", fill="x", expand=True)
        self.cancel_btn = ttk.Button(
            status_frame, text="Batalkan", command=self._cancel, state="disabled"
        )
        self.cancel_btn.pack(side="right")

        self.progress = ttk.Progressbar(outer, mode="determinate", maximum=1)
        self.progress.pack(fill="x", pady=(6, 8))

        log_frame = ttk.LabelFrame(outer, text="Log", padding=6)
        log_frame.pack(fill="both", expand=True)
        self.log_text = scrolledtext.ScrolledText(
            log_frame,
            height=8,
            wrap="word",
            font=("Consolas", 9),
            state="disabled",
        )
        self.log_text.pack(fill="both", expand=True)
        self.log_text.tag_configure("ok", foreground="#087f23")
        self.log_text.tag_configure("fail", foreground="#b00020")
        self.log_text.tag_configure("warn", foreground="#a15c00")
        self.log_text.tag_configure("info", foreground="#222222")

    def _build_encrypt_tab(self, parent: ttk.Frame) -> None:
        parent.columnconfigure(0, weight=1)

        self.enc_panel = TargetPanel(
            parent, self, operation="encrypt", title="Target enkripsi"
        )
        self.enc_panel.grid(row=0, column=0, sticky="ew")

        password_frame = ttk.LabelFrame(parent, text="Password", padding=10)
        password_frame.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        password_frame.columnconfigure(1, weight=1)

        self.enc_password_var = tk.StringVar()
        self.enc_confirm_var = tk.StringVar()
        self.enc_show_var = tk.BooleanVar(value=False)

        ttk.Label(password_frame, text="Password:").grid(
            row=0, column=0, sticky="w", padx=(0, 8), pady=3
        )
        self.enc_password_entry = ttk.Entry(
            password_frame, textvariable=self.enc_password_var, show="*"
        )
        self.enc_password_entry.grid(row=0, column=1, sticky="ew", pady=3)
        ttk.Checkbutton(
            password_frame,
            text="Tampilkan",
            variable=self.enc_show_var,
            command=lambda: self._toggle_show(
                [self.enc_password_entry, self.enc_confirm_entry],
                self.enc_show_var,
            ),
        ).grid(row=0, column=2, padx=(8, 0))
        ttk.Label(password_frame, text=f"Minimal {PASSWORD_MIN} karakter.").grid(
            row=1, column=1, sticky="w"
        )

        ttk.Label(password_frame, text="Ulangi:").grid(
            row=2, column=0, sticky="w", padx=(0, 8), pady=3
        )
        self.enc_confirm_entry = ttk.Entry(
            password_frame, textvariable=self.enc_confirm_var, show="*"
        )
        self.enc_confirm_entry.grid(row=2, column=1, sticky="ew", pady=3)

        self.enc_keyfile_var = tk.StringVar()
        self._build_keyfile_row(password_frame, row=3, variable=self.enc_keyfile_var)

        options = ttk.LabelFrame(parent, text="Verifikasi & penghapusan", padding=10)
        options.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        options.columnconfigure(1, weight=1)

        self.enc_shred_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            options,
            text=(
                "Hapus file asli setelah ciphertext terverifikasi "
                "(best-effort shred)"
            ),
            variable=self.enc_shred_var,
            command=self._update_shred_controls,
        ).grid(row=0, column=0, columnspan=4, sticky="w")

        ttk.Label(options, text="Verifikasi decrypt:").grid(
            row=1, column=0, sticky="w", pady=(8, 0)
        )
        self.enc_verify_var = tk.StringVar(value="2")
        ttk.Spinbox(
            options,
            from_=1,
            to=3,
            textvariable=self.enc_verify_var,
            width=5,
            state="readonly",
        ).grid(row=1, column=1, sticky="w", padx=(8, 20), pady=(8, 0))
        ttk.Label(options, text="pass").grid(row=1, column=2, sticky="w")

        ttk.Label(options, text="Pass shred:").grid(
            row=2, column=0, sticky="w", pady=(6, 0)
        )
        self.enc_shred_passes_var = tk.StringVar(value="1")
        self.enc_shred_spin = ttk.Spinbox(
            options,
            from_=1,
            to=5,
            textvariable=self.enc_shred_passes_var,
            width=5,
            state="readonly",
        )
        self.enc_shred_spin.grid(row=2, column=1, sticky="w", padx=(8, 20), pady=(6, 0))
        ttk.Label(options, text="pass").grid(row=2, column=2, sticky="w", pady=(6, 0))

        ttk.Label(options, text="Worker paralel:").grid(
            row=3, column=0, sticky="w", pady=(6, 0)
        )
        self.enc_workers_var = tk.StringVar(value="4")
        ttk.Spinbox(
            options,
            from_=1,
            to=100,
            textvariable=self.enc_workers_var,
            width=5,
            state="readonly",
        ).grid(row=3, column=1, sticky="w", padx=(8, 20), pady=(6, 0))
        ttk.Label(options, text="file sekaligus (1–100)").grid(
            row=3, column=2, columnspan=2, sticky="w", pady=(6, 0)
        )

        ttk.Label(
            options,
            text=(
                "Verifikasi = decrypt ulang file .fox dan bandingkan SHA-256 "
                "dengan file asli. Shred hanya dijalankan jika semua pass lolos.\n"
                "Tiap worker memakai scrypt ~160 MB RAM; 100 worker ≈ 16 GB. "
                "Sediakan ruang bebas ≈ 2 × worker × file terbesar untuk "
                "output + verifikasi. 2–8 worker biasanya sudah cukup."
            ),
            foreground="#555555",
            wraplength=780,
        ).grid(row=4, column=0, columnspan=4, sticky="w", pady=(8, 0))

        self.enc_start_btn = ttk.Button(
            parent,
            text="Mulai Enkripsi Terverifikasi",
            command=self.start_encrypt,
        )
        self.enc_start_btn.grid(row=3, column=0, sticky="ew", pady=(12, 0))

        self._update_shred_controls()

    def _build_decrypt_tab(self, parent: ttk.Frame) -> None:
        parent.columnconfigure(0, weight=1)

        self.dec_panel = TargetPanel(
            parent, self, operation="decrypt", title="Target dekripsi"
        )
        self.dec_panel.grid(row=0, column=0, sticky="ew")

        password_frame = ttk.LabelFrame(parent, text="Password", padding=10)
        password_frame.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        password_frame.columnconfigure(1, weight=1)

        self.dec_password_var = tk.StringVar()
        self.dec_show_var = tk.BooleanVar(value=False)
        ttk.Label(password_frame, text="Password:").grid(
            row=0, column=0, sticky="w", padx=(0, 8), pady=3
        )
        self.dec_password_entry = ttk.Entry(
            password_frame, textvariable=self.dec_password_var, show="*"
        )
        self.dec_password_entry.grid(row=0, column=1, sticky="ew", pady=3)
        ttk.Checkbutton(
            password_frame,
            text="Tampilkan",
            variable=self.dec_show_var,
            command=lambda: self._toggle_show(
                [self.dec_password_entry], self.dec_show_var
            ),
        ).grid(row=0, column=2, padx=(8, 0))

        self.dec_keyfile_var = tk.StringVar()
        self._build_keyfile_row(password_frame, row=1, variable=self.dec_keyfile_var)

        ttk.Label(password_frame, text="Worker paralel:").grid(
            row=2, column=0, sticky="w", padx=(0, 8), pady=3
        )
        self.dec_workers_var = tk.StringVar(value="4")
        ttk.Spinbox(
            password_frame,
            from_=1,
            to=100,
            textvariable=self.dec_workers_var,
            width=5,
            state="readonly",
        ).grid(row=2, column=1, sticky="w", pady=3)
        ttk.Label(password_frame, text="file sekaligus (1–100)").grid(
            row=2, column=2, sticky="w", padx=(8, 0), pady=3
        )

        ttk.Label(
            parent,
            text=(
                "Hasil dekripsi tidak menimpa file yang sudah ada. "
                "File .fox tetap disimpan. Tiap worker memakai ~160 MB RAM."
            ),
            foreground="#555555",
            wraplength=800,
        ).grid(row=2, column=0, sticky="w", pady=(8, 0))

        self.dec_start_btn = ttk.Button(
            parent,
            text="Mulai Dekripsi",
            command=self.start_decrypt,
        )
        self.dec_start_btn.grid(row=3, column=0, sticky="ew", pady=(12, 0))

    def _build_keyfile_row(
        self, parent: ttk.Frame, *, row: int, variable: tk.StringVar
    ) -> None:
        ttk.Label(parent, text="Keyfile:").grid(
            row=row, column=0, sticky="w", padx=(0, 8), pady=3
        )
        entry = ttk.Entry(parent, textvariable=variable, state="readonly")
        entry.grid(row=row, column=1, sticky="ew", pady=3)

        buttons = ttk.Frame(parent)
        buttons.grid(row=row, column=2, sticky="e", padx=(8, 0), pady=3)

        def choose() -> None:
            selected = filedialog.askopenfilename(
                parent=self,
                title="Pilih keyfile",
            )
            if selected:
                variable.set(selected)

        ttk.Button(buttons, text="Pilih", width=7, command=choose).pack(
            side="left"
        )
        ttk.Button(
            buttons,
            text="Hapus",
            width=7,
            command=lambda: variable.set(""),
        ).pack(side="left", padx=(4, 0))

    def _toggle_show(self, entries: list[ttk.Entry], var: tk.BooleanVar) -> None:
        show = "" if var.get() else "*"
        for entry in entries:
            entry.configure(show=show)

    def _update_shred_controls(self) -> None:
        enabled = bool(getattr(self, "enc_shred_var", None) and self.enc_shred_var.get())
        if hasattr(self, "enc_shred_spin"):
            self.enc_shred_spin.configure(
                state="readonly" if enabled else "disabled"
            )

    # ------------------------------------------------------------------
    # Drives
    # ------------------------------------------------------------------

    def refresh_drives(self, first: bool = False) -> None:
        if self.busy:
            return
        try:
            drives = list_drives()
        except Exception as exc:
            messagebox.showerror(
                "Gagal membaca drive",
                f"Tidak bisa membaca daftar drive:\n{exc}",
                parent=self,
            )
            return
        self.drives = drives
        self.enc_panel.refresh_drives(drives)
        self.dec_panel.refresh_drives(drives)
        if not first:
            self._append_log(f"Daftar drive diperbarui: {len(drives)} drive.", "info")

    # ------------------------------------------------------------------
    # Start operations
    # ------------------------------------------------------------------

    def start_encrypt(self) -> None:
        if self.busy:
            return
        try:
            mode, target, files = self.enc_panel.get_target()
        except Exception as exc:
            messagebox.showerror("Target tidak valid", str(exc), parent=self)
            return

        password = self.enc_password_var.get()
        confirm = self.enc_confirm_var.get()
        if len(password) < PASSWORD_MIN:
            messagebox.showerror(
                "Password terlalu pendek",
                f"Password minimal {PASSWORD_MIN} karakter.",
                parent=self,
            )
            return
        if not hmac.compare_digest(
            unicodedata.normalize("NFC", password).encode("utf-8"),
            unicodedata.normalize("NFC", confirm).encode("utf-8"),
        ):
            messagebox.showerror(
                "Password tidak sama",
                "Password dan ulangi password harus sama.",
                parent=self,
            )
            return

        if mode == "drive":
            info = self.enc_panel.selected_drive()
            if info is None:
                messagebox.showerror("Drive", "Pilih drive.", parent=self)
                return
            if info.is_system:
                messagebox.showerror(
                    "Drive sistem",
                    "Drive sistem (Windows/C:) tidak boleh dienkripsi.",
                    parent=self,
                )
                return
            if info.is_network or info.is_optical:
                messagebox.showerror(
                    "Drive tidak didukung",
                    "Mode seluruh drive hanya untuk disk lokal.",
                    parent=self,
                )
                return
            if not self.enc_shred_var.get():
                messagebox.showerror(
                    "Wajib shred",
                    "Mode seluruh drive mengharuskan opsi shred file asli "
                    "dicentang. File asli tidak boleh ditinggal.",
                    parent=self,
                )
                return
            dialog = DriveConfirmDialog(
                self,
                info,
                operation="encrypt",
                shred=self.enc_shred_var.get(),
            )
            if not dialog.result:
                return
        else:
            if mode == "folder" and is_drive_root(target):
                messagebox.showerror(
                    "Gunakan mode drive",
                    "Target adalah root drive. Pilih mode 'Seluruh drive' "
                    "agar konfirmasi khusus drive muncul.",
                    parent=self,
                )
                return
            if self.enc_shred_var.get():
                if not messagebox.askyesno(
                    "Konfirmasi shred",
                    "File asli akan di-shred setelah setiap ciphertext "
                    "terverifikasi.\n\n"
                    "Ini best-effort dan tidak menjamin pemulihan mustahil "
                    "(terutama di SSD/NVMe). Lanjutkan?",
                    parent=self,
                ):
                    return

        keyfile = self.enc_keyfile_var.get().strip()
        if keyfile and not Path(keyfile).is_file():
            messagebox.showerror(
                "Keyfile tidak ditemukan", keyfile, parent=self
            )
            return

        try:
            verify_passes = int(self.enc_verify_var.get())
            shred_passes = int(self.enc_shred_passes_var.get())
            workers = int(self.enc_workers_var.get())
        except ValueError:
            messagebox.showerror(
                "Opsi tidak valid", "Periksa pass verifikasi/worker.", parent=self
            )
            return
        if not 1 <= workers <= 100:
            messagebox.showerror(
                "Worker tidak valid", "Worker paralel harus 1–100.", parent=self
            )
            return
        if not self._confirm_workers(workers):
            return

        config = BatchConfig(
            operation="encrypt",
            target=target,
            password=password,
            mode=mode,
            files=files,
            shred_originals=self.enc_shred_var.get(),
            shred_passes=shred_passes,
            verify_passes=verify_passes,
            workers=workers,
        )
        self._start_batch(config, keyfile or None, label="Enkripsi")

    def start_decrypt(self) -> None:
        if self.busy:
            return
        try:
            mode, target, files = self.dec_panel.get_target()
        except Exception as exc:
            messagebox.showerror("Target tidak valid", str(exc), parent=self)
            return

        password = self.dec_password_var.get()
        if not password:
            messagebox.showerror("Password", "Masukkan password.", parent=self)
            return

        if mode == "drive":
            info = self.dec_panel.selected_drive()
            if info is None:
                messagebox.showerror("Drive", "Pilih drive.", parent=self)
                return
            if info.is_system:
                messagebox.showerror(
                    "Drive sistem",
                    "Drive sistem tidak boleh diproses dengan mode seluruh drive.",
                    parent=self,
                )
                return
            if info.is_network or info.is_optical:
                messagebox.showerror(
                    "Drive tidak didukung",
                    "Mode seluruh drive hanya untuk disk lokal.",
                    parent=self,
                )
                return
            dialog = DriveConfirmDialog(
                self,
                info,
                operation="decrypt",
                shred=False,
            )
            if not dialog.result:
                return
        else:
            if mode == "folder" and is_drive_root(target):
                messagebox.showerror(
                    "Gunakan mode drive",
                    "Target adalah root drive. Pilih mode 'Seluruh drive'.",
                    parent=self,
                )
                return

        keyfile = self.dec_keyfile_var.get().strip()
        if keyfile and not Path(keyfile).is_file():
            messagebox.showerror(
                "Keyfile tidak ditemukan", keyfile, parent=self
            )
            return

        try:
            workers = int(self.dec_workers_var.get())
        except ValueError:
            messagebox.showerror(
                "Worker tidak valid", "Worker paralel harus 1–100.", parent=self
            )
            return
        if not 1 <= workers <= 100:
            messagebox.showerror(
                "Worker tidak valid", "Worker paralel harus 1–100.", parent=self
            )
            return
        if not self._confirm_workers(workers):
            return

        config = BatchConfig(
            operation="decrypt",
            target=target,
            password=password,
            mode=mode,
            files=files,
            workers=workers,
        )
        self._start_batch(config, keyfile or None, label="Dekripsi")

    # ------------------------------------------------------------------
    # Worker
    # ------------------------------------------------------------------

    def _confirm_workers(self, workers: int) -> bool:
        if workers <= 8:
            return True
        estimate_gb = workers * 160 / 1024
        return bool(
            messagebox.askyesno(
                "Worker sangat tinggi",
                f"{workers} worker paralel memperkirakan ~{estimate_gb:.1f} GB "
                "RAM hanya untuk scrypt, belum termasuk cache/OS.\n\n"
                "Pastikan mesin punya RAM dan I/O cukup. Lanjutkan?",
                parent=self,
            )
        )

    def _start_batch(
        self, config: BatchConfig, keyfile_path: str | None, *, label: str
    ) -> None:
        self.busy = True
        self.cancel_event.clear()
        self._set_busy_ui(True)
        self.progress.configure(maximum=1, value=0)
        self.status_var.set(f"{label}: menyiapkan...")
        self._append_log(
            f"=== Mulai {label.lower()} ===",
            "info",
        )
        self._append_log(f"Target: {config.target}", "info")
        self._append_log(
            f"Mode: {config.mode}, verifikasi: {config.verify_passes}x, "
            f"shred: {config.shred_passes if config.shred_originals else 0}x, "
            f"worker: {config.workers}",
            "info",
        )
        self._append_log(
            "Peringatan: shred bersifat best-effort; SSD/snapshot/ADS tidak "
            "bisa dijamin.",
            "warn",
        )
        thread = threading.Thread(
            target=self._worker,
            args=(config, keyfile_path),
            name="foxcrypt-worker",
            daemon=False,
        )
        thread.start()
        self.after(100, self._poll_queue)

    def _worker(self, config: BatchConfig, keyfile_path: str | None) -> None:
        try:
            if keyfile_path:
                self.queue.put(
                    ("log", {"message": f"Menghitung keyfile: {keyfile_path}"})
                )
                config.keyfile_digest = hash_keyfile(Path(keyfile_path))
            result = run_batch(
                config,
                on_event=lambda kind, data: self.queue.put((kind, data)),
                should_cancel=self.cancel_event.is_set,
            )
            self.queue.put(("batch_done", result))
        except Exception as exc:
            self.queue.put(("batch_error", str(exc)))

    def _poll_queue(self) -> None:
        try:
            while True:
                kind, data = self.queue.get_nowait()
                self._handle_event(kind, data)
        except queue.Empty:
            pass
        if self.busy:
            self.after(100, self._poll_queue)

    def _handle_event(self, kind: str, data: object) -> None:
        payload = data if isinstance(data, dict) else {}
        if kind == "log":
            self._append_log(str(payload.get("message", "")), "info")
        elif kind == "scan":
            total = int(payload.get("total", 0))
            errors = int(payload.get("errors", 0))
            self.progress.configure(maximum=max(1, total), value=0)
            self.status_var.set(f"Memindai: {total} file, {errors} scan error.")
            self._append_log(
                f"Scan selesai: {total} file antre, {errors} error.", "info"
            )
        elif kind == "file_start":
            index = int(payload.get("index", 0))
            total = int(payload.get("total", 0))
            path = str(payload.get("path", ""))
            self.status_var.set(f"Mulai [{index}/{total}]: {path}")
            self._append_log(f"[{index}/{total}] mulai: {path}", "info")
        elif kind == "file_done":
            index = int(payload.get("index", 0))
            completed = int(payload.get("completed", index))
            total = int(payload.get("total", 0))
            outcome = payload.get("outcome")
            self.progress.configure(maximum=max(1, total), value=completed)
            self.status_var.set(f"Selesai {completed}/{total} file.")
            if isinstance(outcome, FileOutcome):
                name = Path(outcome.src).name
                prefix = f"[{completed}/{total}] {name}: "
                if outcome.ok:
                    self._append_log(prefix + f"OK — {outcome.message}", "ok")
                elif outcome.skipped:
                    self._append_log(prefix + f"SKIP — {outcome.message}", "warn")
                else:
                    self._append_log(prefix + f"FAIL — {outcome.message}", "fail")
        elif kind == "audit_start":
            self.status_var.set("Audit akhir...")
            self._append_log("Audit akhir dimulai...", "info")
        elif kind == "batch_done":
            if isinstance(data, BatchResult):
                self._finish_batch(data)
            else:
                self._finish_error("Hasil batch tidak valid.")
        elif kind == "batch_error":
            self._finish_error(str(data))

    def _finish_batch(self, result: BatchResult) -> None:
        self.busy = False
        self._set_busy_ui(False)
        if result.total and not result.canceled:
            self.progress.configure(value=self.progress["maximum"])

        self._append_log(
            f"Ringkasan: total={result.total}, ok={result.succeeded}, "
            f"gagal={result.failed}, skip={result.skipped}, "
            f"shred={result.shredded}, audit_error={result.audit_error_count}, "
            f"waktu={result.elapsed:.1f}s",
            "ok" if result.success else "fail",
        )
        for error in result.audit_errors:
            self._append_log(f"Audit: {error}", "fail")
        if result.canceled:
            self.status_var.set("Dibatalkan. File yang belum selesai tetap aman.")
            self._append_log("Dibatalkan oleh pengguna.", "warn")
            messagebox.showinfo(
                "Dibatalkan",
                "Proses dibatalkan.\n\nFile yang sudah selesai tetap "
                "terenkripsi/terdekripsi; file yang belum selesai tidak "
                "disentuh lebih lanjut.",
                parent=self,
            )
            return

        if result.total == 0 and (result.scan_errors or result.audit_error_count):
            detail = "\n".join((result.scan_errors + result.audit_errors)[:8])
            self.status_var.set("Gagal scan — periksa log.")
            self._append_log("Tidak ada file diproses karena scan gagal.", "fail")
            messagebox.showerror(
                "Gagal scan",
                "Tidak ada file yang diproses karena scan/validasi gagal:\n\n"
                + detail,
                parent=self,
            )
            return

        if result.total == 0:
            self.status_var.set("Tidak ada file yang diproses.")
            self._append_log("Tidak ada file yang cocok untuk diproses.", "warn")
            messagebox.showinfo(
                "Tidak ada file",
                "Tidak ada file yang cocok untuk diproses. Periksa target, "
                "ekstensi, dan filter sistem.",
                parent=self,
            )
            return

        body = (
            f"Total: {result.total}\n"
            f"Berhasil: {result.succeeded}\n"
            f"Gagal: {result.failed}\n"
            f"Dilewati: {result.skipped}\n"
            f"Shred best-effort: {result.shredded}\n"
            f"Scan error: {len(result.scan_errors)}\n"
            f"Waktu: {result.elapsed:.1f} detik"
        )
        if result.scan_errors:
            body += "\n\nScan error:\n" + "\n".join(result.scan_errors[:3])
        if result.audit_error_count:
            body += f"\n\nAudit menemukan {result.audit_error_count} masalah."
            body += "\nLihat log untuk detail. Status BUKAN sukses penuh."
            self.status_var.set("Selesai sebagian — periksa audit/log.")
            self._append_log(
                "PERINGATAN: audit tidak bersih; status bukan sukses penuh.",
                "fail",
            )
            messagebox.showwarning(
                "Selesai sebagian — periksa log",
                body,
                parent=self,
            )
            return

        if not result.success:
            self.status_var.set("Selesai sebagian — ada file gagal.")
            self._append_log(
                "PERINGATAN: ada file gagal/dilewati; status bukan sukses penuh.",
                "fail",
            )
            messagebox.showwarning(
                "Selesai sebagian — periksa log",
                body,
                parent=self,
            )
            return

        if result.operation == "encrypt":
            if result.shredded:
                note = (
                    "File asli sudah di-shred best-effort setelah verifikasi.\n"
                    "CATATAN: ini bukan jaminan fisik. SSD/NVMe, snapshot, "
                    "journal, pagefile, atau alternate data stream dapat "
                    "menyimpan sisa data."
                )
            else:
                note = (
                    "Ciphertext terverifikasi. File asli DIPERTAHANKAN "
                    "karena opsi shred tidak dicentang."
                )
            note += (
                "\n\nFile sistem/metadata, symlink/reparse point, "
                "hardlink, folder aplikasi/Python, dan .fox yang sudah ada "
                "tidak diproses. Lihat log untuk detail."
            )
            if result.mode == "drive":
                note += (
                    "\nMode drive: pengecualian tersebut berarti tidak semua "
                    "file di drive ikut dienkripsi."
                )
        else:
            note = (
                "Dekripsi selesai; tag autentikasi AEAD dan ukuran file "
                "hasil sudah diverifikasi.\n"
                "File .fox di area sistem/symlink/reparse point tidak "
                "diproses."
            )
        self.status_var.set("Selesai & terverifikasi (file yang diproses).")
        self._append_log("Selesai & terverifikasi (audit bersih).", "ok")
        messagebox.showinfo(
            "Selesai & terverifikasi",
            body + "\n\n" + note,
            parent=self,
        )

    def _finish_error(self, message: str) -> None:
        self.busy = False
        self._set_busy_ui(False)
        self.status_var.set("Gagal.")
        self._append_log(f"ERROR: {message}", "fail")
        messagebox.showerror("Gagal", message, parent=self)

    def _set_busy_ui(self, busy: bool) -> None:
        state = "disabled" if busy else "normal"
        self.enc_start_btn.configure(state=state)
        self.dec_start_btn.configure(state=state)
        self.enc_panel.set_busy(busy)
        self.dec_panel.set_busy(busy)
        self.cancel_btn.configure(state="normal" if busy else "disabled")
        for entry in (
            self.enc_password_entry,
            self.enc_confirm_entry,
            self.dec_password_entry,
        ):
            entry.configure(state=state)
        # keyfile entry/button state tetap dapat dibaca; start dikunci.

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------

    def _append_log(self, message: str, tag: str = "info") -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", message.rstrip() + "\n", tag)
        # Jaga agar mode drive dengan ratusan ribu file tidak membuat
        # widget Text menghabiskan memori tanpa batas.
        try:
            line_count = int(self.log_text.index("end-1c").split(".", 1)[0])
            if line_count > 6000:
                self.log_text.delete("1.0", f"{line_count - 4000}.0")
        except (tk.TclError, ValueError):
            pass
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _cancel(self) -> None:
        if not self.busy:
            return
        self.cancel_event.set()
        self.cancel_btn.configure(state="disabled")
        self.status_var.set("Membatalkan setelah file saat ini selesai...")
        self._append_log(
            "Permintaan batal diterima. File yang sedang diproses akan "
            "diselesaikan; jika shred sudah dimulai, pass shred akan "
            "diselesaikan. File berikutnya tidak disentuh.",
            "warn",
        )

    def _on_close(self) -> None:
        if self.busy:
            messagebox.showwarning(
                "Masih berjalan",
                "Proses masih berjalan. Klik 'Batalkan' dan tunggu hingga "
                "file saat ini selesai sebelum menutup aplikasi.",
                parent=self,
            )
            return
        self.destroy()


def _show_fatal(message: str) -> None:
    log_path = APP_ROOT / "foxcrypt-error.log"
    try:
        log_path.write_text(message, encoding="utf-8")
    except OSError:
        pass
    try:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            "FoxCrypt gagal",
            message[-4000:] + f"\n\nLog: {log_path}",
            parent=root,
        )
        root.destroy()
    except Exception:
        if os.name == "nt":
            try:
                import ctypes

                ctypes.windll.user32.MessageBoxW(
                    0, message[-4000:], "FoxCrypt gagal", 0x10
                )
                return
            except Exception:
                pass
        if sys.stderr is not None:
            print(message, file=sys.stderr)


def main() -> int:
    try:
        app = FoxCryptApp()
        app.mainloop()
        return 0
    except Exception:
        _show_fatal(
            "FoxCrypt gagal dijalankan:\n\n" + traceback.format_exc()
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
